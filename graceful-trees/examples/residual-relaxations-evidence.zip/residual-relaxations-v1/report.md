# Exact relaxation certificates for nine fixed residuals

The previous search could not explain these inputs with prime-field congruences. This experiment tests the limitation directly, rather than merely trying more moduli.

| Independently checked result | Cases |
| --- | ---: |
| Signed integer resource cover | 9 |
| Integer functional excludes nonnegative real covers | 8 |
| Exact nonnegative rational resource cover | 1 |

If valid local columns satisfy Az=b for a signed integer z, every functional annihilating A modulo any integer q also annihilates b. Consequently no modular linear-functional certificate of the existing form can exclude that input, at any modulus. A signed cover can use negative coefficients and is not a graceful completion.

A separating certificate has integer row weights w with wA>=0 for every valid local column, but wb<0. Any nonnegative resource cover would give wb=wAz>=0, a contradiction. The independent checker regenerates every injective local assignment and checks the inequalities exactly. This proves only the declared fixed residual impossible.

Cases passing both the integer-lattice and nonnegative-rational relaxations while exact completion fails: [32]. These exact primal certificates demonstrate a limitation of combining those two relaxations. The global permutation oracle checked 42,480 assignments and exhausted every selected input.

## Case 32: an exact gap example

Unused labels and differences are both {1,2,3,4,5}. At parent0 there is a three-vertex fork (root with two leaves) and a two-vertex path. A signed cover is minus fork[2,3,5] plus fork[3,1,2], fork[5,2,3] and path[4,5]. A nonnegative cover gives weight1/2 to each of fork[4,2,3], fork[5,1,3], path[1,4] and path[5,2]. Direct resource sums equal one on each branch, label and difference. Neither is a completion: the former has a negative coefficient; the latter splits branch choices. Full enumeration rejects all120 actual assignments. These displayed examples are independently checked in tests; discovery may return another equally valid certificate.

The underlying central-zero diameter-four obstruction is already covered by van Bussel's classification, reproduced as Theorem 2.54 of [Superdock's 2014 thesis](https://arxiv.org/abs/1403.1564). The general integer-lattice and separating-functional principles are standard. No novelty or breakthrough is claimed for the finite example or certificate machinery.

## A simple separator

Case54 has U={0,1,3,4,6}, D={1,2,3,5,6}, and two two-vertex branches plus one leaf at parent2. Give label6 weight+1, differences5 and6 weight-1, and all other resources weight0. Each valid local option using either large difference consumes label6, and none can use both differences. Every option therefore has nonnegative weight, but the target weight is-1. This is a resource-capacity explanation that congruences cannot supply for this case.

## Reproduction and scope

Run `python scripts/experiment_residual_relaxations.py --output results/residual-relaxations`. Inside the downloaded run archive, run `python3 -S residual_relaxations_verify.py certificates`. The checker needs only the standard library. CP-SAT discovery failures refer to the declared finite coefficient domains and timeout only; they never classify an unbounded relaxation. Exact model/parameter/response files, inputs, seeds, certificates, oracle counts, source snapshots and checksums are preserved. These are exploratory residual certificates, separate from the nightly campaign and its whole-tree counters.
