import Graceful.Basic

/-!
Universal arithmetic verification of the equal-five-edge-leg spider construction.
Legs are numbered `i < k` and positions/edge kinds `j < 5`.  The hub has label 1.
This file states explicitly which parts of the construction are certified.
-/
namespace Graceful.FiveSpider

def a (k i : Nat) : Nat := if i = 0 then 5 * k else 5 * (k - i) + 1
def b (_k i : Nat) : Nat := 5 * i
def c (k i : Nat) : Nat := 5 * (k - 1 - i) + 3
def d (_k i : Nat) : Nat := 5 * i + 4
def e (k i : Nat) : Nat := 5 * (k - 1 - i) + 2

def label (k i j : Nat) : Nat :=
  if j = 0 then a k i else if j = 1 then b k i else
  if j = 2 then c k i else if j = 3 then d k i else e k i

def weight (k i j : Nat) : Nat :=
  if j = 0 then distance 1 (a k i) else
  if j = 1 then distance (a k i) (b k i) else
  if j = 2 then distance (b k i) (c k i) else
  if j = 3 then distance (c k i) (d k i) else
  distance (d k i) (e k i)

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem label_bounded (k i j : Nat) (hi : i < k) (hj : j < 5) :
    label k i j ≤ 5 * k ∧ label k i j ≠ 1 := by
  have cases : j = 0 ∨ j = 1 ∨ j = 2 ∨ j = 3 ∨ j = 4 := by omega
  rcases cases with h | h | h | h | h <;> subst j <;>
    simp [label, a, b, c, d, e] <;> (try split) <;> omega

theorem label_injective (k i j i' j' : Nat)
    (hi : i < k) (hi' : i' < k) (hj : j < 5) (hj' : j' < 5)
    (h : label k i j = label k i' j') : i = i' ∧ j = j' := by
  have jc : j = 0 ∨ j = 1 ∨ j = 2 ∨ j = 3 ∨ j = 4 := by omega
  have jc' : j' = 0 ∨ j' = 1 ∨ j' = 2 ∨ j' = 3 ∨ j' = 4 := by omega
  rcases jc with hj0 | hj0 | hj0 | hj0 | hj0 <;> subst j
  all_goals rcases jc' with hj1 | hj1 | hj1 | hj1 | hj1 <;> subst j'
  all_goals simp [label, a, b, c, d, e] at h ⊢
  all_goals (try split at h) <;> (try split at h) <;> omega

theorem weight_bounded (k i j : Nat) (hi : i < k) (hj : j < 5) :
    0 < weight k i j ∧ weight k i j ≤ 5 * k := by
  have cases : j = 0 ∨ j = 1 ∨ j = 2 ∨ j = 3 ∨ j = 4 := by omega
  rcases cases with h | h | h | h | h <;> subst j
  all_goals simp [weight, a, b, c, d, e, distance]
  all_goals (try split) <;> omega

theorem weight_injective (k i j i' j' : Nat)
    (hi : i < k) (hi' : i' < k) (hj : j < 5) (hj' : j' < 5)
    (h : weight k i j = weight k i' j') : i = i' ∧ j = j' := by
  have jc : j = 0 ∨ j = 1 ∨ j = 2 ∨ j = 3 ∨ j = 4 := by omega
  have jc' : j' = 0 ∨ j' = 1 ∨ j' = 2 ∨ j' = 3 ∨ j' = 4 := by omega
  rcases jc with hj0 | hj0 | hj0 | hj0 | hj0 <;> subst j
  all_goals rcases jc' with hj1 | hj1 | hj1 | hj1 | hj1 <;> subst j'
  all_goals simp [weight, a, b, c, d, e, distance] at h ⊢
  all_goals (try split at h) <;> (try split at h) <;> omega

theorem designated_zero (k : Nat) : label k 0 1 = 0 := by
  simp [label, b]

end Graceful.FiveSpider
