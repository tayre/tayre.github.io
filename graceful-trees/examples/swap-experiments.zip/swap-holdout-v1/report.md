# Swap-search benchmark

Phase: **holdout**. 48 tree shapes; 3 repetitions. Unknowns are censored search outcomes.

![Successes and measured elapsed time](comparison.svg)

| Route | Verified in every repetition | Median total seconds |
| --- | ---: | ---: |
| baseline | 46 / 48 | 2.371009 |
| swaps | 24 / 48 | 28.563142 |
| portfolio | 45 / 48 | 3.363107 |

## Protocol and limits

48 unique non-caterpillar trees: six per family/order at 35 and 75 vertices; excludes every class in all four earlier benchmark corpora. Inputs, objective and method limits are frozen before timing. No tuning after holdout results. Every route uses the same exact CP-SAT fallback and complete attempt wall allowance; candidates get min(0.1s, 10% of that allowance). The portfolio reserves half its candidate time for v3, then gives remaining time to swaps. Baseline and swaps each have a 40000-operation cap; portfolio has 40000 frontier nodes plus 40000 swap proposals. These operations are different and the comparison is equal-time, not equal-work. Method order rotates. Timings measure the whole solve() call, including candidate search and exact-model preparation; archive writing outside solve() and the independent benchmark witness check are excluded. All fallback hashes must match an independently built original model. The fixed proposal policy is missing_difference; missing_difference uses a 3:1 targeted/uniform proposal mixture, while uniform samples vertex pairs uniformly. The policy is selected before this archive's measurements.

All positive labelings were independently verified. Bounded-search failures are unknown; no nongraceful tree, new exhaustive bound, or algorithmic novelty is claimed. Timings describe this machine and capped workload; compare successes and regressions alongside time. The evidence archive is a benchmark, not a campaign checkpoint.

## Paired outcomes

- swaps: consistent gained case indices []; consistent lost case indices [24, 25, 26, 27, 28, 30, 31, 32, 33, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47]. All per-repetition differences are retained in benchmark.json.
- portfolio: consistent gained case indices []; consistent lost case indices [43]. All per-repetition differences are retained in benchmark.json.
