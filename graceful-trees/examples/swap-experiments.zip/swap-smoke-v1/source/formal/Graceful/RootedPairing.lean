import Graceful.Basic

/-!
A concrete obstruction from the bounded rooted-pairing experiment. This concerns
three fixed two-vertex branches, their already assigned parent labels, and a
prescribed partition of remaining differences into internal and attachment roles.
It does not refute gracefulness of any whole tree or completion with another split.
-/
namespace Graceful.RootedPairing

/-- Branches are `0--x0--y0`, `9--x1--y1`, and `9--x2--y2`.
The first permutation gives exactly the six unused labels, with no repetitions.
The other two permutations require exactly the internal and attachment resources,
separately. Parent labels 0 and 9 are excluded from the unused-label resource list.
-/
def Case56Completion (x0 y0 x1 y1 x2 y2 : Nat) : Prop :=
  [x0, y0, x1, y1, x2, y2].Perm [1, 4, 5, 6, 7, 8] ∧
  [distance x0 y0, distance x1 y1, distance x2 y2].Perm [1, 4, 6] ∧
  [distance 0 x0, distance 9 x1, distance 9 x2].Perm [2, 3, 5]

/-- Despite every local resource having some available branch option, these
three branches cannot consume the exact resources together. This is a fixed
residual impossibility theorem, not a general classification or novelty claim.
-/
theorem case56_no_completion (x0 y0 x1 y1 x2 y2 : Nat) :
    ¬ Case56Completion x0 y0 x1 y1 x2 y2 := by
  rintro ⟨hlabels, hinternal, hattachment⟩
  have label_member (v : Nat) (hv : v ∈ [x0, y0, x1, y1, x2, y2]) :
      v ∈ [1, 4, 5, 6, 7, 8] := hlabels.mem_iff.mp hv
  have hx0 := label_member x0 (by simp)
  have hx1 := label_member x1 (by simp)
  have hx2 := label_member x2 (by simp)
  have hy1 := label_member y1 (by simp)
  have hy2 := label_member y2 (by simp)
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx0 hx1 hx2 hy1 hy2
  have distinct : [x0, y0, x1, y1, x2, y2].Nodup :=
    hlabels.nodup_iff.mpr (by decide)
  simp at distinct
  have a0 := hattachment.mem_iff.mp
    (show distance 0 x0 ∈ [distance 0 x0, distance 9 x1, distance 9 x2] by simp)
  have a1 := hattachment.mem_iff.mp
    (show distance 9 x1 ∈ [distance 0 x0, distance 9 x1, distance 9 x2] by simp)
  have a2 := hattachment.mem_iff.mp
    (show distance 9 x2 ∈ [distance 0 x0, distance 9 x1, distance 9 x2] by simp)
  have attachment_distinct :
      [distance 0 x0, distance 9 x1, distance 9 x2].Nodup :=
    hattachment.nodup_iff.mpr (by decide)
  simp only [List.mem_cons, List.not_mem_nil, or_false, distance] at a0 a1 a2
  simp [distance] at attachment_distinct
  have root0 : x0 = 5 := by omega
  have root1 : x1 = 6 ∨ x1 = 7 := by omega
  have root2 : x2 = 6 ∨ x2 = 7 := by omega
  have leaf1 : y1 = 1 ∨ y1 = 4 ∨ y1 = 8 := by omega
  have leaf2 : y2 = 1 ∨ y2 = 4 ∨ y2 = 8 := by omega
  have i1 := hinternal.mem_iff.mp
    (show distance x1 y1 ∈ [distance x0 y0, distance x1 y1, distance x2 y2] by simp)
  have i2 := hinternal.mem_iff.mp
    (show distance x2 y2 ∈ [distance x0 y0, distance x1 y1, distance x2 y2] by simp)
  simp only [List.mem_cons, List.not_mem_nil, or_false, distance] at i1 i2
  omega

end Graceful.RootedPairing
