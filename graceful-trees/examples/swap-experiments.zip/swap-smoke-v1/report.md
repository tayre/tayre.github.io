# Graceful tree research run

Run `2026-11-09T025509.634334_0000-9ce9df0d` · campaign `swap-search-v1`

Started 2026-11-09T02:55:09.634443+00:00; stopped for **case_limit**.
Elapsed 0.579s; configured budget 60s.

[Open the offline visual progress report](report.html) · [Chart data](progress.json) · [Notable review candidates](findings.json)

Download and extract the complete run artifact to open the HTML report and its evidence links.
The charts combine cumulative checkpoint history with this run's search effort.

![Cumulative research progress, size/family outcomes, and current-run search effort](figures/overview.png)

## Evidence summary

- Unique trees investigated (including probes): **100**.
- Unrestricted trees: **100**; verified graceful: **100**.
- Unrestricted unknown: **0**; solver-reported infeasible: **0**.
- Unrestricted trees with independently checked UNSAT certificates: **0**.
- Restricted attempts with independently checked UNSAT certificates: **4** (not counterexamples).
- Attempts: **125** (25 restricted probes).
- Unknown attempts: **0**; observed timeouts: **0**.
- Verified labeling certificates: **121**; errors: **0**.
- Restricted solver-infeasible attempts: **4**, kept separate from the main search.
- Attempts by method: caterpillar-construction: **35**; sat-drup: **25**; swap-portfolio-search: **65**. Unrecorded includes attempts interrupted before the worker returned a method.

A timeout is unresolved. A CP-SAT INFEASIBLE result is a solver conclusion, not an
independently checked proof certificate. No counterexample is declared automatically.
The SAT backend saves scoped DRUP proofs and checks them against an independently regenerated CNF.
These experiments do not prove the universal conjecture or establish novelty.

## Tree sizes (unrestricted searches)

| Vertices | Trees |
| --- | ---: |
| 1 | 1 |
| 2 | 1 |
| 3 | 1 |
| 4 | 2 |
| 5 | 3 |
| 6 | 6 |
| 7 | 11 |
| 12 | 26 |
| 20 | 24 |
| 35 | 25 |

## Performance by input family and size

Family is the first generator that introduced a tree, not an exclusive mathematical classification.
Medians use solved CP-SAT cases only; construction and frontier witnesses have no CP-SAT time or branch count.
Unknowns are censored; different sizes, budgets, hardware
or successful subsets are not controlled comparisons.

| Family | n | Trees | Verified | Unknown | Infeasible | Solved median s | Median branches |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| binary_heap | 12 | 1 | 1 | 0 | 0 | — | None |
| binary_heap | 20 | 1 | 1 | 0 | 0 | — | None |
| binary_heap | 35 | 1 | 1 | 0 | 0 | — | None |
| exhaustive | 1 | 1 | 1 | 0 | 0 | — | None |
| exhaustive | 2 | 1 | 1 | 0 | 0 | — | None |
| exhaustive | 3 | 1 | 1 | 0 | 0 | — | None |
| exhaustive | 4 | 2 | 2 | 0 | 0 | — | None |
| exhaustive | 5 | 3 | 3 | 0 | 0 | — | None |
| exhaustive | 6 | 6 | 6 | 0 | 0 | — | None |
| exhaustive | 7 | 11 | 11 | 0 | 0 | — | None |
| lobster | 12 | 6 | 6 | 0 | 0 | — | None |
| lobster | 20 | 6 | 6 | 0 | 0 | — | None |
| lobster | 35 | 6 | 6 | 0 | 0 | — | None |
| prufer | 12 | 7 | 7 | 0 | 0 | — | None |
| prufer | 20 | 6 | 6 | 0 | 0 | — | None |
| prufer | 35 | 6 | 6 | 0 | 0 | — | None |
| recursive | 12 | 7 | 7 | 0 | 0 | — | None |
| recursive | 20 | 6 | 6 | 0 | 0 | — | None |
| recursive | 35 | 6 | 6 | 0 | 0 | — | None |
| spider | 12 | 5 | 5 | 0 | 0 | — | None |
| spider | 20 | 5 | 5 | 0 | 0 | — | None |
| spider | 35 | 6 | 6 | 0 | 0 | — | None |

## Cases to investigate

Unresolved and infeasible cases come first, then deterministic work and branch count.
Wall times include dispatch overhead; exact inputs and all attempts are in the ledger.

| Tree ID | n | Family | Status | Wall s | Branches | Leaves | Diameter |
| --- | ---: | --- | --- | ---: | ---: | ---: | ---: |
| [287628c154e6](inputs/287628c154e67057da3fc8c08b47aa1cce86f2630bf810f9807e46c3ff0ab0bc.json) | 1 | exhaustive | verified_graceful | 0.085 | — | 0 | 0 |
| [23fa6a51716c](inputs/23fa6a51716c2168a1484b196f2739d7d5175508037d41f42726fb9e23791b4c.json) | 35 | lobster | verified_graceful | 0.011 | — | 20 | 14 |
| [1562506bdfcf](inputs/1562506bdfcf531669d42947244916a9492cb0ddf331b3a6cbf217625d791643.json) | 35 | recursive | verified_graceful | 0.007 | — | 19 | 8 |
| [5734890f9f44](inputs/5734890f9f44495fc8f38789847b6b4a0222e64ebcff2e16ea521d4c8e276218.json) | 35 | prufer | verified_graceful | 0.006 | — | 13 | 14 |
| [845edda37ba5](inputs/845edda37ba596a4618de625277a9a225fd4359d0f4cbe813433708cee9c16af.json) | 35 | binary_heap | verified_graceful | 0.006 | — | 18 | 9 |
| [a1e78ef910d4](inputs/a1e78ef910d49a801784544b54c67e983175d864773d8e0bdec4362235113df0.json) | 20 | binary_heap | verified_graceful | 0.004 | — | 10 | 7 |
| [d969b88751aa](inputs/d969b88751aac0a5f4fceba3a2e396103ec2b24cf428e3274df934e559dd4f62.json) | 35 | recursive | verified_graceful | 0.004 | — | 16 | 12 |
| [96ba90fa4676](inputs/96ba90fa467627b327c2064fef6903167c1337ce74353158b2f754b74bc38449.json) | 35 | spider | verified_graceful | 0.002 | — | 6 | 17 |
| [d0066b5dce22](inputs/d0066b5dce22e8f479c81f3fbb9129802bf1795710295ad49550230ba4fcbfdd.json) | 35 | recursive | verified_graceful | 0.002 | — | 16 | 11 |
| [f0b4f4e3e5b2](inputs/f0b4f4e3e5b24ee404f100f50c97c7f059e8444c81e8da805c22dddd2802bfc2.json) | 35 | lobster | verified_graceful | 0.002 | — | 21 | 14 |
| [19ce0692caa3](inputs/19ce0692caa37072a957de57e631c258e89ccf5cae35fffdea562c180ecf4f1c.json) | 12 | binary_heap | verified_graceful | 0.002 | — | 6 | 6 |
| [810383899a65](inputs/810383899a658aff8288f9569d864d9312530fda39cb5a4994706a44dc5399e5.json) | 35 | spider | verified_graceful | 0.001 | — | 7 | 13 |
| [2f209cc33aca](inputs/2f209cc33acae1b35c4fb329e34fc439e4f94b815154e323dba7274f9f58a392.json) | 35 | spider | verified_graceful | 0.001 | — | 5 | 16 |
| [e3433e47952e](inputs/e3433e47952e7d19332cc8c5442f27029309f8ee0b5f661350d8d0f09f7b004a.json) | 35 | spider | verified_graceful | 0.001 | — | 4 | 19 |
| [94d2bcd431c8](inputs/94d2bcd431c885412f5252441f9f881468dd4d2899fab347c15da069d9516b93.json) | 35 | spider | verified_graceful | 0.001 | — | 4 | 22 |

Branch-count outliers (>3× same-order solved CP-SAT median, ≥5 CP-SAT peers, >50 branches): 0.
This is a triage rule, not a statistical significance test.

## Extreme-edge observations

Cumulative checkpoint contains 13 partially or fully probed trees.
`analysis.json` records every edge orbit, witnesses, exclusions reported by the solver,
and untested/unknown orbits. Each checked exclusion is explicitly marked with its proof status.
Infeasibility for a prescribed edge does not imply that the tree is nongraceful.

## Proposed next experiments (unproven)

- **pendant-extreme-support-lobsters**: For every lobster T that is not a caterpillar, there is a graceful labeling whose edge of difference |V(T)|-1 is incident to a leaf. Status: candidate question; truth and novelty not asserted. Enumerate non-caterpillar lobsters at a declared order; test every pendant edge orbit. Caterpillars already satisfy this by the known construction. One verified pendant witness establishes the property for that tree. Excluding all pendant orbits requires independently checked UNSAT evidence.

## Reproducibility and coverage

See `manifest.json` for exact versions, seeds, source hashes, configuration, hardware,
generation cursors and cumulative counts. `attempts.jsonl` and CSV describe this run;
`research.sqlite` carries the complete accumulated inputs, attempts, witnesses and proof text.
`unsat-certificates/` contains checked negative certificates; each binds the exact input and restriction.
`certificates/` contains standalone witnesses. Model/parameter/response protos are retained
per attempt when the worker reached those stages. `checksums.json` covers saved files.
Run `graceful-research audit RUN_DIRECTORY` before using results.

Cumulative unique inputs: 100; cumulative attempts: 125.
Generation stopping or exhausting a configured stream alone does not certify exhaustive
gracefulness verification. Inspect unresolved inputs and enumeration counts as well.
