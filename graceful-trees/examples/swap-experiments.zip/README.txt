Uniform development, targeted development, fresh holdout, and the audited 100-tree CLI validation. No tuning followed the holdout. The nightly default remains v3.
Each experiment retains its own source snapshot and checksums. Benchmark and residual folders are not campaign checkpoints.
