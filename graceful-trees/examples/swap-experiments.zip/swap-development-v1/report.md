# Swap-search benchmark

Phase: **development**. 48 tree shapes; 3 repetitions. Unknowns are censored search outcomes.

![Successes and measured elapsed time](comparison.svg)

| Route | Verified in every repetition | Median total seconds |
| --- | ---: | ---: |
| missing_count | 0 / 48 | 3.593150 |
| missing_sum | 1 / 48 | 3.516704 |

## Protocol and limits

Existing 48-tree portfolio corpus, explicitly development data. Compare missing-count and missing-sum swap objectives without exact fallback, each with 40000 proposals and min(0.1s, 10% of the configured attempt allowance). Alternate objective order. Seed and corpus are fixed; wall cutoffs may vary. Choose an objective and freeze the algorithm before running the separate fresh holdout. Scores from the two objectives have different scales and are not compared numerically across objectives.

All positive labelings were independently verified. Bounded-search failures are unknown; no nongraceful tree, new exhaustive bound, or algorithmic novelty is claimed. Timings describe this machine and capped workload; compare successes and regressions alongside time. The evidence archive is a benchmark, not a campaign checkpoint.

## Paired outcomes

- missing_count: consistent gained case indices []; consistent lost case indices [2]. All per-repetition differences are retained in benchmark.json.
