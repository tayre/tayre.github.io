# Graceful tree research run

Run `2026-11-08T163829.157175_0000-e814aec2` · campaign `nightly-v1`

Started 2026-11-08T16:38:29.157263+00:00; stopped for **case_limit**.
Elapsed 5.902s; configured budget 20.0s.

[Open the offline visual progress report](report.html) · [Chart data](progress.json)

Download and extract the complete run artifact to open the HTML report and its evidence links.
The charts combine cumulative checkpoint history with this run's search effort.

![Cumulative research progress, size/family outcomes, and current-run search effort](figures/overview.png)

## Evidence summary

- Unique trees investigated (including probes): **17**.
- Unrestricted trees: **12**; verified graceful: **11**.
- Unrestricted unknown: **1**; solver-reported infeasible: **0**.
- Independently certificate-verified infeasible: **0** (unsupported by this backend).
- Attempts: **52** (40 restricted probes).
- Unknown attempts: **1**; observed timeouts: **1**.
- Verified labeling certificates: **51**; errors: **0**.
- Restricted solver-infeasible attempts: **0**, kept separate from the main search.

A timeout is unresolved. A CP-SAT INFEASIBLE result is a solver conclusion, not an
independently checked proof certificate. No counterexample is declared automatically.
These experiments do not prove the universal conjecture or establish novelty.

## Tree sizes (unrestricted searches)

| Vertices | Trees |
| --- | ---: |
| 8 | 1 |
| 9 | 1 |
| 10 | 1 |
| 11 | 1 |
| 12 | 1 |
| 35 | 6 |
| 75 | 1 |

## Performance by input family and size

Family is the first generator that introduced a tree, not an exclusive mathematical classification.
Medians include solved cases only. Unknowns are censored; different sizes, budgets, hardware
or successful subsets are not controlled comparisons.

| Family | n | Trees | Verified | Unknown | Infeasible | Solved median s | Median branches |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| broom | 35 | 1 | 1 | 0 | 0 | 0.3623 | 45430 |
| broom | 75 | 1 | 0 | 1 | 0 | — | None |
| caterpillar | 35 | 1 | 1 | 0 | 0 | 0.3283 | 39551 |
| exhaustive | 8 | 1 | 1 | 0 | 0 | 0.0068 | 1137 |
| exhaustive | 9 | 1 | 1 | 0 | 0 | 0.0077 | 1570 |
| exhaustive | 10 | 1 | 1 | 0 | 0 | 0.0108 | 1990 |
| exhaustive | 11 | 1 | 1 | 0 | 0 | 0.0110 | 2574 |
| exhaustive | 12 | 1 | 1 | 0 | 0 | 0.0135 | 3208 |
| lobster | 35 | 1 | 1 | 0 | 0 | 0.1976 | 35746 |
| prufer | 35 | 1 | 1 | 0 | 0 | 0.1768 | 34995 |
| recursive | 35 | 1 | 1 | 0 | 0 | 0.2749 | 38512 |
| spider | 35 | 1 | 1 | 0 | 0 | 0.2004 | 35571 |

## Cases to investigate

Unresolved and infeasible cases come first, then deterministic work and branch count.
Wall times include dispatch overhead; exact inputs and all attempts are in the ledger.

| Tree ID | n | Family | Status | Wall s | Branches | Leaves | Diameter |
| --- | ---: | --- | --- | ---: | ---: | ---: | ---: |
| [5f903b426fd7](inputs/5f903b426fd7275667a419a311e3e72484b7d5482e31ba09ff9267fb9627548b.json) | 75 | broom | unknown | 3.588 | — | 60 | 16 |
| [ec3f3bbc3505](inputs/ec3f3bbc35057179d3658be3c8f0cde937ac1d8ce3572704ad8add58ebc1eea4.json) | 35 | broom | verified_graceful | 0.366 | 45430 | 15 | 21 |
| [421c26e84a0e](inputs/421c26e84a0ed08e76b330dbb6826a055d5c8b0c95638bcf024ebd47b6ec832e.json) | 35 | caterpillar | verified_graceful | 0.332 | 39551 | 7 | 29 |
| [d969b88751aa](inputs/d969b88751aac0a5f4fceba3a2e396103ec2b24cf428e3274df934e559dd4f62.json) | 35 | recursive | verified_graceful | 0.278 | 38512 | 16 | 12 |
| [e3433e47952e](inputs/e3433e47952e7d19332cc8c5442f27029309f8ee0b5f661350d8d0f09f7b004a.json) | 35 | spider | verified_graceful | 0.204 | 35571 | 4 | 19 |
| [92c2bb3a0c68](inputs/92c2bb3a0c68c5ab3ab58002b2b24d34254c7b036c459a097327fc1bf2baadc3.json) | 35 | lobster | verified_graceful | 0.201 | 35746 | 20 | 12 |
| [36f62eb15445](inputs/36f62eb1544522ecafb183b2c8c10f7f76df9cb712fe3d2af30e4a468c399cfc.json) | 35 | prufer | verified_graceful | 0.180 | 34995 | 13 | 19 |
| [88c6992f8b61](inputs/88c6992f8b612a1b22b2ddc44304145dd861fbf0d145724db3bdf691f9c01cad.json) | 12 | exhaustive | verified_graceful | 0.015 | 3208 | 4 | 9 |
| [b05d333ce7f4](inputs/b05d333ce7f4cccb6661703d67087013c578c175f9a05a011c42f106d1f777a3.json) | 11 | exhaustive | verified_graceful | 0.012 | 2574 | 4 | 8 |
| [78374b744f95](inputs/78374b744f95d60da5eefe8cb67ccc255d39e5bf02d62c347d675266f945069e.json) | 10 | exhaustive | verified_graceful | 0.012 | 1990 | 4 | 7 |
| [83834dc9ac8d](inputs/83834dc9ac8d603a769b9ab27c4395fc0dcc06ee987a53ad7ebda0086d889091.json) | 9 | exhaustive | verified_graceful | 0.009 | 1570 | 4 | 6 |
| [1e9f25aa5591](inputs/1e9f25aa559160fdc9669288e07f53d0913eec6a364e83bdb7fbf3817e034e0a.json) | 8 | exhaustive | verified_graceful | 0.285 | 1137 | 4 | 5 |

Branch-count outliers (>3× same-order solved median, ≥5 peers, >50 branches): 0.
This is a triage rule, not a statistical significance test.

## Extreme-edge observations

Cumulative checkpoint contains 31 partially or fully probed trees.
`analysis.json` records every edge orbit, witnesses, exclusions reported by the solver,
and untested/unknown orbits. Only witnessed membership is independently verified.
Infeasibility for a prescribed edge does not imply that the tree is nongraceful.

## Proposed next experiments (unproven)

- **pendant-extreme-support**: For every caterpillar T with at least two vertices, there is a graceful labeling whose edge of difference |V(T)|-1 is incident to a leaf. Status: candidate question; truth and novelty not asserted. Enumerate caterpillars at a declared order; test every pendant edge orbit. One verified pendant witness establishes the property for that tree. Excluding all pendant orbits requires independently checked UNSAT evidence.
- **censored-retries**: Repeat unresolved inputs with larger budgets and multiple logged seeds. Status: algorithm benchmark, not a mathematical conjecture. Match size, solver version, model options and CPU; report censoring explicitly.

## Reproducibility and coverage

See `manifest.json` for exact versions, seeds, source hashes, configuration, hardware,
generation cursors and cumulative counts. `attempts.jsonl` and CSV describe this run;
`research.sqlite` carries the complete accumulated inputs, attempts and positive witnesses.
`certificates/` contains standalone witnesses. Model/parameter/response protos are retained
per attempt when the worker reached those stages. `checksums.json` covers saved files.
Run `graceful-research audit RUN_DIRECTORY` before using results.

Cumulative unique inputs: 102; cumulative attempts: 226.
Generation stopping or exhausting a configured stream alone does not certify exhaustive
gracefulness verification. Inspect unresolved inputs and enumeration counts as well.
