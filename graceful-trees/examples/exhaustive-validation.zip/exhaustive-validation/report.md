# Graceful tree research run

Run `2026-11-08T150500.962485_0000-2d10f4bd` · campaign `exhaustive-small-v1`

Started 2026-11-08T15:05:00.962568+00:00; stopped for **sources_exhausted**.
Elapsed 1.469s; configured budget 120s.

## Evidence summary

- Unique trees investigated (including probes): **95**.
- Unrestricted trees: **95**; verified graceful: **95**.
- Unrestricted unknown: **0**; solver-reported infeasible: **0**.
- Independently certificate-verified infeasible: **0** (unsupported by this backend).
- Attempts: **155** (60 restricted probes).
- Unknown attempts: **0**; observed timeouts: **0**.
- Verified labeling certificates: **150**; errors: **0**.
- Restricted solver-infeasible attempts: **5**, kept separate from the main search.

A timeout is unresolved. A CP-SAT INFEASIBLE result is a solver conclusion, not an
independently checked proof certificate. No counterexample is declared automatically.
These experiments do not prove the universal conjecture or establish novelty.

## Tree sizes (unrestricted searches)

| Vertices | Trees |
| --- | ---: |
| 1 | 1 |
| 2 | 1 |
| 3 | 1 |
| 4 | 2 |
| 5 | 3 |
| 6 | 6 |
| 7 | 11 |
| 8 | 23 |
| 9 | 47 |

## Performance by input family and size

Family is the first generator that introduced a tree, not an exclusive mathematical classification.
Medians include solved cases only. Unknowns are censored; different sizes, budgets, hardware
or successful subsets are not controlled comparisons.

| Family | n | Trees | Verified | Unknown | Infeasible | Solved median s | Median branches |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| exhaustive | 1 | 1 | 1 | 0 | 0 | 0.0003 | 0 |
| exhaustive | 2 | 1 | 1 | 0 | 0 | 0.0002 | 0 |
| exhaustive | 3 | 1 | 1 | 0 | 0 | 0.0004 | 0 |
| exhaustive | 4 | 2 | 2 | 0 | 0 | 0.0007 | 32.0 |
| exhaustive | 5 | 3 | 3 | 0 | 0 | 0.0024 | 140 |
| exhaustive | 6 | 6 | 6 | 0 | 0 | 0.0032 | 400.0 |
| exhaustive | 7 | 11 | 11 | 0 | 0 | 0.0050 | 752 |
| exhaustive | 8 | 23 | 23 | 0 | 0 | 0.0065 | 1115 |
| exhaustive | 9 | 47 | 47 | 0 | 0 | 0.0073 | 1520 |

## Cases to investigate

Unresolved and infeasible cases come first, then deterministic work and branch count.
Wall times include dispatch overhead; exact inputs and all attempts are in the ledger.

| Tree ID | n | Family | Status | Wall s | Branches | Leaves | Diameter |
| --- | ---: | --- | --- | ---: | ---: | ---: | ---: |
| [1da66c94531a](inputs/1da66c94531afa9f4e958708854bc3d7155d27de9c94b8a2a9e505c71de28610.json) | 9 | exhaustive | verified_graceful | 0.011 | 1564 | 2 | 8 |
| [9a927d180dc5](inputs/9a927d180dc541b7548f189d7b41e7c8e0b82d1b55780184491d78d40c09ee0d.json) | 9 | exhaustive | verified_graceful | 0.011 | 1556 | 6 | 4 |
| [25a26c8ffdb4](inputs/25a26c8ffdb4783f619db43d06e43071e70bdcc5cb369d5120999cde6843f8fc.json) | 9 | exhaustive | verified_graceful | 0.011 | 1533 | 3 | 7 |
| [e668a26c790f](inputs/e668a26c790f9361aa9342cf0aafae81b1c7fe89fc440bc1f094638128b218b1.json) | 9 | exhaustive | verified_graceful | 0.011 | 1583 | 3 | 7 |
| [f011037b7572](inputs/f011037b757246b6d2923d2489973b2f826814a16c6141cf7e38d5cacc0ad091.json) | 9 | exhaustive | verified_graceful | 0.010 | 1520 | 4 | 5 |
| [1f9a49d3a94b](inputs/1f9a49d3a94bed7c58b327cb10cd4e460bce24bae0c848745fb0d8470059b3fd.json) | 9 | exhaustive | verified_graceful | 0.010 | 1434 | 4 | 4 |
| [1d09b6fcbdd7](inputs/1d09b6fcbdd71e3bb8c9a2ba7c74e10a36659c774372a6d716e5a435b727eff1.json) | 9 | exhaustive | verified_graceful | 0.010 | 1432 | 5 | 4 |
| [789b73701461](inputs/789b7370146126420fd0b95fe541bfc6c45680ac9ce605f0f3972f4f88251a44.json) | 9 | exhaustive | verified_graceful | 0.011 | 1520 | 3 | 7 |
| [dd7b3c5d0d5e](inputs/dd7b3c5d0d5eae11b9311303070fdd49ac17d502d9d3ffba797fd1d2ac3ec241.json) | 9 | exhaustive | verified_graceful | 0.010 | 1430 | 6 | 4 |
| [1aa35438a099](inputs/1aa35438a0994a31f9e5e7f398a42c7207ddddb7ffcb0e2dad30cec0b305a9a9.json) | 9 | exhaustive | verified_graceful | 0.010 | 1525 | 5 | 5 |
| [66bbc5fb55e0](inputs/66bbc5fb55e0751828b58b1f43abde52d40f9b0ed5b556f1ef94ee6a2eb36e26.json) | 9 | exhaustive | verified_graceful | 0.009 | 1567 | 3 | 6 |
| [6af56fd8888b](inputs/6af56fd8888b081d3b8f68910c3125381852f907d83fc6371ddcc2d284ac6f71.json) | 9 | exhaustive | verified_graceful | 0.011 | 1404 | 6 | 4 |
| [e5b868a116ad](inputs/e5b868a116adc792d6dd0e5c35b944e08b2af15af08df52ec0c4a07c0da58ee8.json) | 9 | exhaustive | verified_graceful | 0.010 | 1541 | 4 | 6 |
| [e633eef0a024](inputs/e633eef0a024e6477fcad58a61444a30a1172976e9a273c72ca2498d8102d769.json) | 9 | exhaustive | verified_graceful | 0.010 | 1518 | 5 | 4 |
| [d7fccd5430f8](inputs/d7fccd5430f824ebb24287a0314a4de3d367e9d269c2556e537da277a2b123d6.json) | 9 | exhaustive | verified_graceful | 0.010 | 1518 | 5 | 5 |

Branch-count outliers (>3× same-order solved median, ≥5 peers, >50 branches): 0.
This is a triage rule, not a statistical significance test.

## Extreme-edge observations

Cumulative checkpoint contains 23 partially or fully probed trees.
`analysis.json` records every edge orbit, witnesses, exclusions reported by the solver,
and untested/unknown orbits. Only witnessed membership is independently verified.
Infeasibility for a prescribed edge does not imply that the tree is nongraceful.

## Proposed next experiments (unproven)

- **pendant-extreme-support**: For every caterpillar T with at least two vertices, there is a graceful labeling whose edge of difference |V(T)|-1 is incident to a leaf. Status: candidate question; truth and novelty not asserted. Enumerate caterpillars at a declared order; test every pendant edge orbit. One verified pendant witness establishes the property for that tree. Excluding all pendant orbits requires independently checked UNSAT evidence.

## Reproducibility and coverage

See `manifest.json` for exact versions, seeds, source hashes, configuration, hardware,
generation cursors and cumulative counts. `attempts.jsonl` and CSV describe this run;
`research.sqlite` carries the complete accumulated inputs, attempts and positive witnesses.
`certificates/` contains standalone witnesses. Model/parameter/response protos are retained
per attempt when the worker reached those stages. `checksums.json` covers saved files.
Run `graceful-research audit RUN_DIRECTORY` before using results.

Cumulative unique inputs: 95; cumulative attempts: 155.
Generation stopping or exhausting a configured stream alone does not certify exhaustive
gracefulness verification. Inspect unresolved inputs and enumeration counts as well.
