# Graceful tree research run

Run `2026-11-08T150214.071357_0000-f41361d9` · campaign `nightly-v1`

Started 2026-11-08T15:02:14.071458+00:00; stopped for **case_limit**.
Elapsed 7.201s; configured budget 30.0s.

## Evidence summary

- Unique trees investigated (including probes): **26**.
- Unrestricted trees: **20**; verified graceful: **18**.
- Unrestricted unknown: **2**; solver-reported infeasible: **0**.
- Independently certificate-verified infeasible: **0** (unsupported by this backend).
- Attempts: **60** (40 restricted probes).
- Unknown attempts: **2**; observed timeouts: **1**.
- Verified labeling certificates: **55**; errors: **0**.
- Restricted solver-infeasible attempts: **3**, kept separate from the main search.

A timeout is unresolved. A CP-SAT INFEASIBLE result is a solver conclusion, not an
independently checked proof certificate. No counterexample is declared automatically.
These experiments do not prove the universal conjecture or establish novelty.

## Tree sizes (unrestricted searches)

| Vertices | Trees |
| --- | ---: |
| 6 | 2 |
| 7 | 2 |
| 8 | 1 |
| 9 | 1 |
| 10 | 1 |
| 11 | 1 |
| 12 | 1 |
| 20 | 7 |
| 50 | 1 |
| 75 | 3 |

## Performance by input family and size

Family is the first generator that introduced a tree, not an exclusive mathematical classification.
Medians include solved cases only. Unknowns are censored; different sizes, budgets, hardware
or successful subsets are not controlled comparisons.

| Family | n | Trees | Verified | Unknown | Infeasible | Solved median s | Median branches |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| broom | 20 | 1 | 1 | 0 | 0 | 0.0784 | 12498 |
| broom | 50 | 1 | 0 | 1 | 0 | — | None |
| caterpillar | 20 | 1 | 1 | 0 | 0 | 0.0753 | 12452 |
| caterpillar | 75 | 1 | 1 | 0 | 0 | 4.7557 | 481553 |
| double_star | 20 | 1 | 1 | 0 | 0 | 0.0368 | 9736 |
| double_star | 75 | 1 | 1 | 0 | 0 | 0.9940 | 150807 |
| exhaustive | 6 | 2 | 2 | 0 | 0 | 0.0031 | 308.0 |
| exhaustive | 7 | 2 | 2 | 0 | 0 | 0.0054 | 782.5 |
| exhaustive | 8 | 1 | 1 | 0 | 0 | 0.0083 | 1116 |
| exhaustive | 9 | 1 | 1 | 0 | 0 | 0.0085 | 1559 |
| exhaustive | 10 | 1 | 1 | 0 | 0 | 0.0131 | 2026 |
| exhaustive | 11 | 1 | 1 | 0 | 0 | 0.0139 | 2560 |
| exhaustive | 12 | 1 | 1 | 0 | 0 | 0.0171 | 3254 |
| lobster | 20 | 1 | 1 | 0 | 0 | 0.0482 | 10318 |
| prufer | 20 | 1 | 1 | 0 | 0 | 0.0446 | 9737 |
| recursive | 20 | 1 | 1 | 0 | 0 | 0.0451 | 9803 |
| spider | 20 | 1 | 1 | 0 | 0 | 0.0474 | 9967 |
| star | 75 | 1 | 0 | 1 | 0 | — | None |

## Cases to investigate

Unresolved and infeasible cases come first, then deterministic work and branch count.
Wall times include dispatch overhead; exact inputs and all attempts are in the ledger.

| Tree ID | n | Family | Status | Wall s | Branches | Leaves | Diameter |
| --- | ---: | --- | --- | ---: | ---: | ---: | ---: |
| [c3b4da66efa5](inputs/c3b4da66efa5fbe51368549d0c7df4029837b33222d60c496bf54c7497da4750.json) | 75 | star | unknown | 0.301 | 0 | 74 | 2 |
| [ab8f0e32a2dd](inputs/ab8f0e32a2dd1eef0dbc305254d304e93617162659ed0e15d869e8bbfacd8683.json) | 50 | broom | unknown | 0.031 | 0 | 38 | 13 |
| [5f2f12587dca](inputs/5f2f12587dcaaf5b09f5115ebc51fd532c7ce65b7788858db5c7622285090b52.json) | 75 | caterpillar | verified_graceful | 5.040 | 481553 | 11 | 65 |
| [e6fc50907dba](inputs/e6fc50907dba7821352a40bfa483418b42b8da7727257787b67f04dca5da1b49.json) | 75 | double_star | verified_graceful | 1.003 | 150807 | 73 | 3 |
| [381c85d9ba03](inputs/381c85d9ba03469edb6477e9c0946cccb23cce9ac3c32ccb06d3671b247b56b0.json) | 20 | broom | verified_graceful | 0.081 | 12498 | 11 | 10 |
| [4c5229386f7d](inputs/4c5229386f7d7bb172b0919e1996226bd14d8cdce83958bc2169f6d7b1c82f28.json) | 20 | caterpillar | verified_graceful | 0.078 | 12452 | 16 | 5 |
| [db007be3c999](inputs/db007be3c999d808574cf62dfc0cf11f373de6850a86593cb7859bb87c1793b1.json) | 20 | lobster | verified_graceful | 0.050 | 10318 | 13 | 6 |
| [91c3cdc8d5fe](inputs/91c3cdc8d5fe09a4b4e257bb33c33fb7cee85faaf703cf7dbcd17a0eb072c38b.json) | 20 | spider | verified_graceful | 0.050 | 9967 | 3 | 15 |
| [e304fa3d6c60](inputs/e304fa3d6c608e504e43fc302d7c7bef9477579236082fb73a3106f6c14f8597.json) | 20 | recursive | verified_graceful | 0.048 | 9803 | 7 | 12 |
| [9cbf72a25625](inputs/9cbf72a256254062c2c5c9a605a679ef711b819e4a213eb1b2e16d843d4c8db6.json) | 20 | prufer | verified_graceful | 0.047 | 9737 | 5 | 12 |
| [fc2191ef9a23](inputs/fc2191ef9a23290def04e1f2d16d09c8f723f27ac105158ccc9d95dd25d2075c.json) | 20 | double_star | verified_graceful | 0.039 | 9736 | 18 | 3 |
| [ebc2f18d1789](inputs/ebc2f18d17898137670ab92aa7cb281593d2bbcae76e021d913068c5f832a32a.json) | 12 | exhaustive | verified_graceful | 0.019 | 3254 | 4 | 9 |
| [90c568b41fe5](inputs/90c568b41fe5bac23c48280b33d321f64b3d40d4022c97d14dc4910e5d928c74.json) | 11 | exhaustive | verified_graceful | 0.016 | 2560 | 3 | 9 |
| [a14458102029](inputs/a14458102029f6faa8d0bc4e0d203f5541e0f3e90e75ac2ff058a3a7a73de1ad.json) | 10 | exhaustive | verified_graceful | 0.015 | 2026 | 4 | 7 |
| [48e576396b3b](inputs/48e576396b3b0a606011f781f0857a216059ac71091ef054a9952005233b0158.json) | 9 | exhaustive | verified_graceful | 0.010 | 1559 | 4 | 6 |

Branch-count outliers (>3× same-order solved median, ≥5 peers, >50 branches): 0.
This is a triage rule, not a statistical significance test.

## Extreme-edge observations

Cumulative checkpoint contains 25 partially or fully probed trees.
`analysis.json` records every edge orbit, witnesses, exclusions reported by the solver,
and untested/unknown orbits. Only witnessed membership is independently verified.
Infeasibility for a prescribed edge does not imply that the tree is nongraceful.

## Proposed next experiments (unproven)

- **pendant-extreme-support**: For every caterpillar T with at least two vertices, there is a graceful labeling whose edge of difference |V(T)|-1 is incident to a leaf. Status: candidate question; truth and novelty not asserted. Enumerate caterpillars at a declared order; test every pendant edge orbit. One verified pendant witness establishes the property for that tree. Excluding all pendant orbits requires independently checked UNSAT evidence.
- **censored-retries**: Repeat unresolved inputs with larger budgets and multiple logged seeds. Status: algorithm benchmark, not a mathematical conjecture. Match size, solver version, model options and CPU; report censoring explicitly.

## Reproducibility and coverage

See `manifest.json` for exact versions, seeds, source hashes, configuration, hardware,
generation cursors and cumulative counts. `attempts.jsonl` and CSV describe this run;
`research.sqlite` carries the complete accumulated inputs, attempts and positive witnesses.
`certificates/` contains standalone witnesses. Model/parameter/response protos are retained
per attempt when the worker reached those stages. `checksums.json` covers saved files.
Run `graceful-research audit RUN_DIRECTORY` before using results.

Cumulative unique inputs: 91; cumulative attempts: 174.
Generation stopping or exhausting a configured stream alone does not certify exhaustive
gracefulness verification. Inspect unresolved inputs and enumeration counts as well.
