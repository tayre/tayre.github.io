# Graceful tree research run

Run `2026-11-14T035254.637510_0000-bd09c275` · campaign `nightly-v1`

Started 2026-11-14T03:52:54.637631+00:00; stopped for **compute_budget**.
Elapsed 216.013s; configured budget 240.0s.

[Open the offline visual progress report](report.html) · [Chart data](progress.json) · [Notable review candidates](findings.json)

Download and extract the complete run artifact to open the HTML report and its evidence links.
The charts combine cumulative checkpoint history with this run's search effort.

![Cumulative research progress, size/family outcomes, and current-run search effort](figures/overview.png)

## Evidence summary

- Unique trees investigated (including probes): **2186**.
- Unrestricted trees: **2180**; verified graceful: **2156**.
- Unrestricted unknown: **24**; solver-reported infeasible: **0**.
- Unrestricted trees with independently checked UNSAT certificates: **0**.
- Restricted attempts with independently checked UNSAT certificates: **9** (not counterexamples).
- Attempts: **2438** (258 restricted probes).
- Unknown attempts: **24**; observed timeouts: **24**.
- Verified labeling certificates: **2404**; errors: **0**.
- Restricted solver-infeasible attempts: **10**, kept separate from the main search.
- Attempts by method: caterpillar-construction: **814**; cp-sat: **28**; frontier-search: **1336**; sat-drup: **258**; unrecorded: **2**. Unrecorded includes attempts interrupted before the worker returned a method.

A timeout is unresolved. A CP-SAT INFEASIBLE result is a solver conclusion, not an
independently checked proof certificate. No counterexample is declared automatically.
The SAT backend saves scoped DRUP proofs and checks them against an independently regenerated CNF.
These experiments do not prove the universal conjecture or establish novelty.

## Research budget use

Eligible unresolved/pending trees at start: 0.
Phase wall times include generation and dispatch; setup and final reporting are separate.
Unused retry time flows to new trees; enabled budget filling also reuses unspent probe time.

| Phase | Attempts | Wall seconds |
| --- | ---: | ---: |
| retries | 0 | 0.001 |
| new trees | 2180 | 161.774 |
| edge probes | 258 | 53.904 |

## Tree sizes (unrestricted searches)

| Vertices | Trees |
| --- | ---: |
| 8 | 2 |
| 9 | 26 |
| 10 | 85 |
| 11 | 214 |
| 12 | 295 |
| 20 | 344 |
| 35 | 380 |
| 50 | 406 |
| 75 | 428 |

## Performance by input family and size

Family is the first generator that introduced a tree, not an exclusive mathematical classification.
Medians use solved CP-SAT cases only; construction and frontier witnesses have no CP-SAT time or branch count.
Unknowns are censored; different sizes, budgets, hardware
or successful subsets are not controlled comparisons.

| Family | n | Trees | Verified | Unknown | Infeasible | Solved median s | Median branches |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| broom | 20 | 10 | 10 | 0 | 0 | — | None |
| broom | 35 | 22 | 22 | 0 | 0 | — | None |
| broom | 50 | 29 | 29 | 0 | 0 | — | None |
| broom | 75 | 44 | 44 | 0 | 0 | — | None |
| caterpillar | 20 | 70 | 70 | 0 | 0 | — | None |
| caterpillar | 35 | 71 | 71 | 0 | 0 | — | None |
| caterpillar | 50 | 74 | 74 | 0 | 0 | — | None |
| caterpillar | 75 | 71 | 71 | 0 | 0 | — | None |
| double_star | 20 | 5 | 5 | 0 | 0 | — | None |
| double_star | 35 | 11 | 11 | 0 | 0 | — | None |
| double_star | 50 | 19 | 19 | 0 | 0 | — | None |
| double_star | 75 | 26 | 26 | 0 | 0 | — | None |
| exhaustive | 8 | 2 | 2 | 0 | 0 | — | None |
| exhaustive | 9 | 26 | 26 | 0 | 0 | — | None |
| exhaustive | 10 | 85 | 85 | 0 | 0 | — | None |
| exhaustive | 11 | 214 | 214 | 0 | 0 | — | None |
| exhaustive | 12 | 295 | 295 | 0 | 0 | — | None |
| lobster | 20 | 73 | 73 | 0 | 0 | — | None |
| lobster | 35 | 74 | 74 | 0 | 0 | — | None |
| lobster | 50 | 74 | 74 | 0 | 0 | — | None |
| lobster | 75 | 74 | 67 | 7 | 0 | 3.3741 | 201146 |
| prufer | 20 | 73 | 73 | 0 | 0 | — | None |
| prufer | 35 | 74 | 74 | 0 | 0 | — | None |
| prufer | 50 | 74 | 74 | 0 | 0 | — | None |
| prufer | 75 | 74 | 70 | 4 | 0 | — | None |
| recursive | 20 | 73 | 73 | 0 | 0 | — | None |
| recursive | 35 | 74 | 74 | 0 | 0 | — | None |
| recursive | 50 | 74 | 74 | 0 | 0 | — | None |
| recursive | 75 | 74 | 69 | 5 | 0 | 3.1288 | 173086 |
| spider | 20 | 40 | 40 | 0 | 0 | — | None |
| spider | 35 | 54 | 54 | 0 | 0 | — | None |
| spider | 50 | 62 | 62 | 0 | 0 | — | None |
| spider | 75 | 65 | 57 | 8 | 0 | — | None |

## Cases to investigate

Unresolved and infeasible cases come first, then deterministic work and branch count.
Wall times include dispatch overhead; exact inputs and all attempts are in the ledger.

| Tree ID | n | Family | Status | Wall s | Branches | Leaves | Diameter |
| --- | ---: | --- | --- | ---: | ---: | ---: | ---: |
| [f38b2ca4e085](inputs/f38b2ca4e08592784636e04c56e847f4b96163e490f2a486ad4a7d944027e5cd.json) | 75 | spider | unknown | 5.429 | 220194 | 10 | 22 |
| [6d0d94b8cb82](inputs/6d0d94b8cb823c8d7394b1f971cc63f16f4ed2eb4a1b0b842c984cd3aeb9d115.json) | 75 | prufer | unknown | 5.013 | 211466 | 26 | 26 |
| [f9f04beb6495](inputs/f9f04beb6495253dadd8613966c63ad4528f5da085590d897781aa7213ec4284.json) | 75 | spider | unknown | 5.019 | 223251 | 9 | 20 |
| [0ebb00b70ebc](inputs/0ebb00b70ebcb5a4115e8201b067f868d450f4794448bcbfd720110be5df4abb.json) | 75 | recursive | unknown | 5.034 | 246834 | 40 | 10 |
| [e01be1196bca](inputs/e01be1196bcaba21f6a9b3ed384e73b059a53b1118db5f0364347e1d29b1fe40.json) | 75 | spider | unknown | 5.012 | 212241 | 9 | 24 |
| [03931119a6d8](inputs/03931119a6d8bb93c466a09ca6c469931dc0b80b84e56ca52a61a55a06d7414c.json) | 75 | lobster | unknown | 5.011 | 210388 | 41 | 25 |
| [21f6e6c1ae44](inputs/21f6e6c1ae44317004e72339ee65c6874503a3afbf243508abac4b8a7e2a15e7.json) | 75 | lobster | unknown | 5.015 | 201702 | 39 | 27 |
| [51360707c5cd](inputs/51360707c5cdaf519de5d5ca47941c6382a9d59a26983f7ec4cbef1e332baf03.json) | 75 | lobster | unknown | 5.017 | 203662 | 38 | 26 |
| [2d60e05d5e14](inputs/2d60e05d5e14d77d5a9884e09f05ab8d1d1cc07c0bddbd0fb37c149f331a8e01.json) | 75 | lobster | unknown | 5.020 | 211761 | 40 | 27 |
| [09fe86b08936](inputs/09fe86b089360a9224caaf17dd327310637a5597de18c0c775481054c2ce1e73.json) | 75 | spider | unknown | 5.009 | 194141 | 8 | 24 |
| [a35cdfba459a](inputs/a35cdfba459a30483ffb3cb14225c74baec7c63499f29765b01bbcdabf19519c.json) | 75 | spider | unknown | 5.011 | 190807 | 9 | 26 |
| [838455f2de58](inputs/838455f2de588f1df2f89f71c4b1368ed5fcf74ebefc3bc4e06f47945f060ad5.json) | 75 | recursive | unknown | 5.009 | 205821 | 33 | 13 |
| [8d4caa08fb19](inputs/8d4caa08fb1925572aba71020f311001ff833c611e3b9fce966810256083419e.json) | 75 | spider | unknown | 5.019 | 187138 | 10 | 24 |
| [2a292dc0e639](inputs/2a292dc0e639027f3c49aa3f3a8962cc15a07e5c6dbfea7ee0b6d5775d728404.json) | 75 | spider | unknown | 5.047 | 181537 | 10 | 18 |
| [29a19aab78e6](inputs/29a19aab78e6622e19ae0bd0c136151a6b5fa1c17869f5abc7ccdaaa364d354c.json) | 75 | recursive | unknown | 5.044 | 182805 | 38 | 13 |

Branch-count outliers (>3× same-order solved CP-SAT median, ≥5 CP-SAT peers, >50 branches): 0.
This is a triage rule, not a statistical significance test.

## Extreme-edge observations

Cumulative checkpoint contains 121 partially or fully probed trees.
`analysis.json` records every edge orbit, witnesses, exclusions reported by the solver,
and untested/unknown orbits. Each checked exclusion is explicitly marked with its proof status.
Infeasibility for a prescribed edge does not imply that the tree is nongraceful.

## Proposed next experiments (unproven)

- **pendant-extreme-support-lobsters**: For every lobster T that is not a caterpillar, there is a graceful labeling whose edge of difference |V(T)|-1 is incident to a leaf. Status: candidate question; truth and novelty not asserted. Enumerate non-caterpillar lobsters at a declared order; test every pendant edge orbit. Caterpillars already satisfy this by the known construction. One verified pendant witness establishes the property for that tree. Excluding all pendant orbits requires independently checked UNSAT evidence.
- **censored-retries**: Repeat unresolved inputs with larger budgets and multiple logged seeds. Status: algorithm benchmark, not a mathematical conjecture. Match size, solver version, model options and CPU; report censoring explicitly.

## Reproducibility and coverage

See `manifest.json` for exact versions, seeds, source hashes, configuration, hardware,
generation cursors and cumulative counts. `attempts.jsonl` and CSV describe this run;
`research.sqlite` carries the complete accumulated inputs, attempts, witnesses and proof text.
`unsat-certificates/` contains checked negative certificates; each binds the exact input and restriction.
`certificates/` contains standalone witnesses. Model/parameter/response protos are retained
per attempt when the worker reached those stages. `checksums.json` covers saved files.
Run `graceful-research audit RUN_DIRECTORY` before using results.

Cumulative unique inputs: 2461; cumulative attempts: 3047.
Generation stopping or exhausting a configured stream alone does not certify exhaustive
gracefulness verification. Inspect unresolved inputs and enumeration counts as well.
