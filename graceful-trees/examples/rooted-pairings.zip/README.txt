Exact rooted-pairing classifications and a separately kernel-checked Lean proof of one fixed residual obstruction. No whole-tree counterexample or novelty is claimed.
Each experiment retains its own source snapshot and checksums. Benchmark and residual folders are not campaign checkpoints.
