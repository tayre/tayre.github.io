# Rooted short-branch completion experiment

82 unique fixed resource problems; all exact classifications agreed with an independent permutation oracle (795,109 assignments examined).

Each branch has two unassigned vertices joined to its declared already assigned parent. Internal and attachment differences are prescribed separately. An impossible residual is not a nongraceful tree. These finite exhaustive searches do not produce independently checkable UNSAT proof certificates, and no mathematical novelty is claimed.

| Classification | Cases |
| --- | ---: |
| attachment_obstruction | 21 |
| completion | 24 |
| necessary_condition_obstruction | 35 |
| pairing_obstruction_beyond_conditions | 2 |

The corpus includes constructed positive controls and internally pairable controls. It is not exhaustive over resource patterns, a random-tree sample, or an estimate of how often this technique would help nightly search. Exact inputs are frozen before classification and duplicates are recorded rather than counted twice.

## What the observations distinguish

Necessary-condition failures violate Skolem parity or density. A pairing failure beyond those conditions shows they are insufficient for that resource set. Attachment failures admit the prescribed internal pairing but cannot orient and allocate its pairs among the declared parent labels while consuming exactly the attachment differences.

The known Nordh example is retained as a control, not a discovery. The attachment-only examples are candidates for a future boundary-compatibility classification; this run does not establish a new general theorem.

## Local availability versus joint resource conflicts

Each branch's local table lists every ordered pair of unused labels satisfying its internal and attachment requirements in isolation. These necessary coverage checks do not enforce disjointness between branches and are not sufficient for completion.

Of the 21 attachment obstructions, 4 have a nonempty local table for every branch and cover every attachment difference somewhere. Of those, 1 also cover every unused label and internal difference. The other examples retain a direct local availability obstruction. Diagnostic categories can overlap.

The named control `attachments_compete_for_one_internal_pair` passes the branch and attachment checks, but label 2 appears in no local option. Covering attachment differences alone therefore misses an elementary label-resource obstruction.

- [Case 56: every local resource is available](cases/056.json)

## Recommended next experiment

Group the smallest attachment failures by resource intervals, holes and parent labels. Test a specifically formulated construction or obstruction on a separately fixed corpus, compare it with Skolem/Langford and transfer results, and seek a proof with explicit assumptions. These measurements do not justify adding a nightly pruning rule.

## Reproduction

`inputs.json` saves every resource input; `cases/` saves all internal pairing tables, witnesses and independent oracle outcomes. `protocol.json`, `source/`, dependency versions and `checksums.json` preserve the measured implementation. This is an experimental archive, not a campaign checkpoint accepted by `graceful-research audit`.
