# Graceful tree research run

Run `2026-11-15T015118.097358_0000-53e231e6` · campaign `focused-validation-v1`

Started 2026-11-15T01:51:18.097469+00:00; stopped for **case_limit**.
Elapsed 0.706s; configured budget 30s.

[Open the offline visual progress report](report.html) · [Chart data](progress.json) · [Notable review candidates](findings.json)

Download and extract the complete run artifact to open the HTML report and its evidence links.
The charts combine cumulative checkpoint history with this run's search effort.

![Cumulative research progress, size/family outcomes, and current-run search effort](figures/overview.png)

## Evidence summary

- Unique trees investigated (including probes): **54**.
- Unrestricted trees: **50**; verified graceful: **50**.
- Unrestricted unknown: **0**; solver-reported infeasible: **0**.
- Unrestricted trees with independently checked UNSAT certificates: **0**.
- Restricted attempts with independently checked UNSAT certificates: **2** (not counterexamples).
- Attempts: **58** (8 restricted probes).
- Unknown attempts: **0**; observed timeouts: **0**.
- Verified labeling certificates: **56**; errors: **0**.
- Restricted solver-infeasible attempts: **2**, kept separate from the main search.
- Attempts by method: caterpillar-construction: **21**; frontier-search: **29**; sat-drup: **8**. Unrecorded includes attempts interrupted before the worker returned a method.

A timeout is unresolved. A CP-SAT INFEASIBLE result is a solver conclusion, not an
independently checked proof certificate. No counterexample is declared automatically.
The SAT backend saves scoped DRUP proofs and checks them against an independently regenerated CNF.
These experiments do not prove the universal conjecture or establish novelty.

## Research budget use

Eligible unresolved/pending trees at start: 0.
Phase wall times include generation and dispatch; setup and final reporting are separate.
Unused retry time flows to new trees; enabled budget filling also reuses unspent probe time.

| Phase | Attempts | Wall seconds |
| --- | ---: | ---: |
| retries | 0 | 0.000 |
| new trees | 50 | 0.267 |
| edge probes | 8 | 0.086 |
| focused study | 0 | 0.183 |

## Tree sizes (unrestricted searches)

| Vertices | Trees |
| --- | ---: |
| 7 | 5 |
| 12 | 20 |
| 20 | 25 |

## Performance by input family and size

Family is the first generator that introduced a tree, not an exclusive mathematical classification.
Medians use solved CP-SAT cases only; construction and frontier witnesses have no CP-SAT time or branch count.
Unknowns are censored; different sizes, budgets, hardware
or successful subsets are not controlled comparisons.

| Family | n | Trees | Verified | Unknown | Infeasible | Solved median s | Median branches |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| caterpillar | 12 | 6 | 6 | 0 | 0 | — | None |
| caterpillar | 20 | 6 | 6 | 0 | 0 | — | None |
| exhaustive | 7 | 5 | 5 | 0 | 0 | — | None |
| lobster | 12 | 6 | 6 | 0 | 0 | — | None |
| lobster | 20 | 7 | 7 | 0 | 0 | — | None |
| prufer | 12 | 5 | 5 | 0 | 0 | — | None |
| prufer | 20 | 6 | 6 | 0 | 0 | — | None |
| spider | 12 | 3 | 3 | 0 | 0 | — | None |
| spider | 20 | 6 | 6 | 0 | 0 | — | None |

## Cases to investigate

Unresolved and infeasible cases come first, then deterministic work and branch count.
Wall times include dispatch overhead; exact inputs and all attempts are in the ledger.

| Tree ID | n | Family | Status | Wall s | Branches | Leaves | Diameter |
| --- | ---: | --- | --- | ---: | ---: | ---: | ---: |
| [10cde823d8aa](inputs/10cde823d8aad34542891f9ee94692eafb7b6632c2945e8336c5b575fd0472de.json) | 20 | lobster | verified_graceful | 0.064 | — | 11 | 7 |
| [6715c6dd4ac2](inputs/6715c6dd4ac27e67afb569c88baac89973f84eee5aee21f99d23c5c1c4809a93.json) | 20 | lobster | verified_graceful | 0.003 | — | 12 | 8 |
| [767e33a4711e](inputs/767e33a4711edf74552ff5f343fab9b675fa91f6fb0afbb21f2e2fe1792d6ab9.json) | 20 | spider | verified_graceful | 0.002 | — | 6 | 9 |
| [0ef529223814](inputs/0ef529223814fbed9964c40cda8d545f4b08df7734b0039a47c146fabdaeed04.json) | 20 | caterpillar | verified_graceful | 0.002 | — | 17 | 4 |
| [3eeaa0e6846e](inputs/3eeaa0e6846e13ff1f8172b5cf8f85502c129a22c5f4025883987afe8f67b06d.json) | 12 | lobster | verified_graceful | 0.001 | — | 8 | 5 |
| [5b5c6f9c7188](inputs/5b5c6f9c718812e191e9a372fabfecbd1e7cf044843328eeddf2f552218662db.json) | 12 | prufer | verified_graceful | 0.001 | — | 6 | 6 |
| [c1c8b3d886f2](inputs/c1c8b3d886f25d76dc9d152dad4211a69d9d722e663feed69267ce783240f1ed.json) | 20 | lobster | verified_graceful | 0.001 | — | 12 | 8 |
| [544a086174c4](inputs/544a086174c4e1a34344a80580a9b4392bc2d55195f030c7296c8afd7e5cac91.json) | 20 | caterpillar | verified_graceful | 0.001 | — | 17 | 4 |
| [c593d8cfa689](inputs/c593d8cfa68918ccfd8962694a0e29d2f5bb98eb961fe21ce4b8a3cc0a782aea.json) | 20 | spider | verified_graceful | 0.001 | — | 3 | 16 |
| [27c7adb2479f](inputs/27c7adb2479f5bc7c7f9397031b8c013cb992bdfefb7b259c8fc8588a127d24d.json) | 20 | prufer | verified_graceful | 0.001 | — | 8 | 9 |
| [5b1bd98b9a44](inputs/5b1bd98b9a440ac92803a3c4f092828c2e3b71a4369bbbf28395f94c05ac6e21.json) | 12 | prufer | verified_graceful | 0.001 | — | 6 | 6 |
| [50055f6f87e7](inputs/50055f6f87e7611e06f6172de7bac4ee5f8b63a6e607e3c7078e69a648bdcf26.json) | 20 | prufer | verified_graceful | 0.001 | — | 8 | 8 |
| [005ba068d297](inputs/005ba068d297820cae372afea7cface95e48d4bf9342d5d283ebc2b58498721b.json) | 12 | spider | verified_graceful | 0.001 | — | 5 | 6 |
| [9576fa150694](inputs/9576fa150694282404791b1b77148fd5836d211544f3c16f1671146154c875ae.json) | 20 | spider | verified_graceful | 0.001 | — | 4 | 11 |
| [1f815cdf55f7](inputs/1f815cdf55f7e3145ee5f961645443ef5672e6c6a9f5e09eb77b8eb82fbea02b.json) | 20 | lobster | verified_graceful | 0.001 | — | 11 | 8 |

Branch-count outliers (>3× same-order solved CP-SAT median, ≥5 CP-SAT peers, >50 branches): 0.
This is a triage rule, not a statistical significance test.

## Extreme-edge observations

Cumulative checkpoint contains 9 partially or fully probed trees.
`analysis.json` records every edge orbit, witnesses, exclusions reported by the solver,
and untested/unknown orbits. Each checked exclusion is explicitly marked with its proof status.
Infeasibility for a prescribed edge does not imply that the tree is nongraceful.

## Proposed next experiments (unproven)

- **pendant-extreme-support-lobsters**: For every lobster T that is not a caterpillar, there is a graceful labeling whose edge of difference |V(T)|-1 is incident to a leaf. Status: candidate question; truth and novelty not asserted. Enumerate non-caterpillar lobsters at a declared order; test every pendant edge orbit. Caterpillars already satisfy this by the known construction. One verified pendant witness establishes the property for that tree. Excluding all pendant orbits requires independently checked UNSAT evidence.

## Reproducibility and coverage

See `manifest.json` for exact versions, seeds, source hashes, configuration, hardware,
generation cursors and cumulative counts. `attempts.jsonl` and CSV describe this run;
`research.sqlite` carries the complete accumulated inputs, attempts, witnesses and proof text.
`unsat-certificates/` contains checked negative certificates; each binds the exact input and restriction.
`certificates/` contains standalone witnesses. Model/parameter/response protos are retained
per attempt when the worker reached those stages. `checksums.json` covers saved files.
Run `graceful-research audit RUN_DIRECTORY` before using results.

Cumulative unique inputs: 100; cumulative attempts: 117.
Generation stopping or exhausting a configured stream alone does not certify exhaustive
gracefulness verification. Inspect unresolved inputs and enumeration counts as well.


## Focused nightly investigation

Does matching contraction improve verified successes under the same total per-input allowance?

Study: **matching**. Saved 3 records; stop: `batch_limit`.

[Machine-readable study summary](focused/summary.json). Detailed inputs and evidence are under `focused/records/`.

These observations do not extend exhaustive coverage or assert mathematical novelty.

```json
{
  "comparison": {
    "baseline_only": 0,
    "both_verified": 3,
    "by_stratum": {
      "natural_prufer": {
        "baseline_only": 0,
        "both_verified": 3,
        "complete_pairs": 3,
        "fully_solved_times": {
          "baseline": {
            "median_seconds": 0.0007624579593539238,
            "total_seconds": 0.0028598749195225537
          },
          "matching_first": {
            "median_seconds": 0.0007965409895405173,
            "total_seconds": 0.0024908320046961308
          },
          "pairs": 3,
          "scope": "only pairs with two verified witnesses and two recorded elapsed times"
        },
        "incomplete_pairs": 0,
        "matching_only": 0,
        "neither_verified": 0,
        "records": 3,
        "status_counts": {
          "baseline": {
            "verified_graceful": 3
          },
          "matching_first": {
            "verified_graceful": 3
          }
        }
      }
    },
    "complete_pairs": 3,
    "fully_solved_times": {
      "baseline": {
        "median_seconds": 0.0007624579593539238,
        "total_seconds": 0.0028598749195225537
      },
      "matching_first": {
        "median_seconds": 0.0007965409895405173,
        "total_seconds": 0.0024908320046961308
      },
      "pairs": 3,
      "scope": "only pairs with two verified witnesses and two recorded elapsed times"
    },
    "incomplete_pairs": 0,
    "matching_only": 0,
    "neither_verified": 0,
    "records": 3,
    "scope": "finite paired measurements; unknown results are censored",
    "status_counts": {
      "baseline": {
        "verified_graceful": 3
      },
      "matching_first": {
        "verified_graceful": 3
      }
    }
  },
  "pairs_completed": 3,
  "pairs_started": 3
}
```