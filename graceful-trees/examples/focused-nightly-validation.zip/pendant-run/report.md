# Graceful tree research run

Run `2026-11-15T015050.001911_0000-22b086d1` · campaign `focused-validation-v1`

Started 2026-11-15T01:50:50.002440+00:00; stopped for **case_limit**.
Elapsed 0.884s; configured budget 30s.

[Open the offline visual progress report](report.html) · [Chart data](progress.json) · [Notable review candidates](findings.json)

Download and extract the complete run artifact to open the HTML report and its evidence links.
The charts combine cumulative checkpoint history with this run's search effort.

![Cumulative research progress, size/family outcomes, and current-run search effort](figures/overview.png)

## Evidence summary

- Unique trees investigated (including probes): **50**.
- Unrestricted trees: **50**; verified graceful: **50**.
- Unrestricted unknown: **0**; solver-reported infeasible: **0**.
- Unrestricted trees with independently checked UNSAT certificates: **0**.
- Restricted attempts with independently checked UNSAT certificates: **1** (not counterexamples).
- Attempts: **59** (9 restricted probes).
- Unknown attempts: **0**; observed timeouts: **0**.
- Verified labeling certificates: **58**; errors: **0**.
- Restricted solver-infeasible attempts: **1**, kept separate from the main search.
- Attempts by method: caterpillar-construction: **33**; frontier-search: **17**; sat-drup: **9**. Unrecorded includes attempts interrupted before the worker returned a method.

A timeout is unresolved. A CP-SAT INFEASIBLE result is a solver conclusion, not an
independently checked proof certificate. No counterexample is declared automatically.
The SAT backend saves scoped DRUP proofs and checks them against an independently regenerated CNF.
These experiments do not prove the universal conjecture or establish novelty.

## Research budget use

Eligible unresolved/pending trees at start: 0.
Phase wall times include generation and dispatch; setup and final reporting are separate.
Unused retry time flows to new trees; enabled budget filling also reuses unspent probe time.

| Phase | Attempts | Wall seconds |
| --- | ---: | ---: |
| retries | 0 | 0.000 |
| new trees | 47 | 0.147 |
| edge probes | 8 | 0.037 |
| focused study | 4 | 0.476 |

## Tree sizes (unrestricted searches)

| Vertices | Trees |
| --- | ---: |
| 1 | 1 |
| 2 | 1 |
| 3 | 1 |
| 4 | 2 |
| 5 | 3 |
| 6 | 6 |
| 7 | 6 |
| 12 | 14 |
| 14 | 1 |
| 16 | 1 |
| 18 | 1 |
| 20 | 13 |

## Performance by input family and size

Family is the first generator that introduced a tree, not an exclusive mathematical classification.
Medians use solved CP-SAT cases only; construction and frontier witnesses have no CP-SAT time or branch count.
Unknowns are censored; different sizes, budgets, hardware
or successful subsets are not controlled comparisons.

| Family | n | Trees | Verified | Unknown | Infeasible | Solved median s | Median branches |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| binary_heap | 12 | 1 | 1 | 0 | 0 | — | None |
| binary_heap | 20 | 1 | 1 | 0 | 0 | — | None |
| caterpillar | 12 | 3 | 3 | 0 | 0 | — | None |
| caterpillar | 20 | 3 | 3 | 0 | 0 | — | None |
| exhaustive | 1 | 1 | 1 | 0 | 0 | — | None |
| exhaustive | 2 | 1 | 1 | 0 | 0 | — | None |
| exhaustive | 3 | 1 | 1 | 0 | 0 | — | None |
| exhaustive | 4 | 2 | 2 | 0 | 0 | — | None |
| exhaustive | 5 | 3 | 3 | 0 | 0 | — | None |
| exhaustive | 6 | 6 | 6 | 0 | 0 | — | None |
| exhaustive | 7 | 6 | 6 | 0 | 0 | — | None |
| lobster | 12 | 3 | 3 | 0 | 0 | — | None |
| lobster | 14 | 1 | 1 | 0 | 0 | — | None |
| lobster | 16 | 1 | 1 | 0 | 0 | — | None |
| lobster | 18 | 1 | 1 | 0 | 0 | — | None |
| lobster | 20 | 2 | 2 | 0 | 0 | — | None |
| path | 12 | 1 | 1 | 0 | 0 | — | None |
| path | 20 | 1 | 1 | 0 | 0 | — | None |
| prufer | 12 | 3 | 3 | 0 | 0 | — | None |
| prufer | 20 | 3 | 3 | 0 | 0 | — | None |
| spider | 12 | 2 | 2 | 0 | 0 | — | None |
| spider | 20 | 2 | 2 | 0 | 0 | — | None |
| star | 12 | 1 | 1 | 0 | 0 | — | None |
| star | 20 | 1 | 1 | 0 | 0 | — | None |

## Cases to investigate

Unresolved and infeasible cases come first, then deterministic work and branch count.
Wall times include dispatch overhead; exact inputs and all attempts are in the ledger.

| Tree ID | n | Family | Status | Wall s | Branches | Leaves | Diameter |
| --- | ---: | --- | --- | ---: | ---: | ---: | ---: |
| [bfa5f20389d2](inputs/bfa5f20389d2cac7a9e006b1ecd392bb8e118bb16a2eb17e6313b38d62b54796.json) | 14 | lobster | verified_graceful | 0.075 | — | 9 | 5 |
| [a1e78ef910d4](inputs/a1e78ef910d49a801784544b54c67e983175d864773d8e0bdec4362235113df0.json) | 20 | binary_heap | verified_graceful | 0.004 | — | 10 | 7 |
| [f1c84c746cec](inputs/f1c84c746cec8bc0bd4a1ffc08c79be5db6f3226a62cce3bd71167cbb6e269e1.json) | 20 | prufer | verified_graceful | 0.001 | — | 10 | 9 |
| [bb3e6016f499](inputs/bb3e6016f499a82bb8cbb20e66781d2916a4bce7cff33ee6a6c5e21e28b86247.json) | 20 | spider | verified_graceful | 0.001 | — | 4 | 12 |
| [e1411faf7d1b](inputs/e1411faf7d1b5ab77743be652454b6766f24450c9fa7eccc34a828178a2d52ef.json) | 18 | lobster | verified_graceful | 0.001 | — | 9 | 7 |
| [1295fc4b6aff](inputs/1295fc4b6aff51c129919c533cc9d9d95296f919b1b5a734f86339a96ca25501.json) | 20 | prufer | verified_graceful | 0.001 | — | 10 | 10 |
| [e434c0f94b40](inputs/e434c0f94b40ad93c0f0bbff1aaa249079d021cb100c7718d51e781d5694c795.json) | 6 | exhaustive | verified_graceful | 0.001 | — | 5 | 2 |
| [282edbb144a8](inputs/282edbb144a82ebeda9e20f5a7b163222289f334d5e8b00945e111f4b41270a6.json) | 20 | lobster | verified_graceful | 0.001 | — | 10 | 9 |
| [f0e3745d75b4](inputs/f0e3745d75b43360fc18d076596a3832a3fe3baaf3f418eae7b03c58337a309d.json) | 7 | exhaustive | verified_graceful | 0.001 | — | 4 | 4 |
| [6a9e4892360a](inputs/6a9e4892360a3a637e9d7488158c1760401888da75ae73e826bfd9b4ea7a660f.json) | 20 | prufer | verified_graceful | 0.001 | — | 9 | 9 |
| [b286491d4229](inputs/b286491d4229526c97355cabdafb5f53ed99dc158dff48bd2454b0cc1cda3588.json) | 16 | lobster | verified_graceful | 0.001 | — | 8 | 7 |
| [f807159a6f74](inputs/f807159a6f74f18f137c28947c85d6007c62b54263fd4c197935335c618272ec.json) | 20 | spider | verified_graceful | 0.001 | — | 6 | 10 |
| [98a4b7e9ac00](inputs/98a4b7e9ac003048e8681ff39ebd93ed77b0273fb18b75db35da75484f915081.json) | 12 | lobster | verified_graceful | 0.001 | — | 7 | 5 |
| [984e1932be25](inputs/984e1932be25fbd8da0eedd75cece45034745bfa90b7b7d2a06e2b9d6bc1daf8.json) | 12 | spider | verified_graceful | 0.001 | — | 3 | 8 |
| [020c71e9d95e](inputs/020c71e9d95e137bb21ede8b1dcf52b50c1e92ca6beadce39c9844e03f5e73d8.json) | 12 | prufer | verified_graceful | 0.001 | — | 6 | 6 |

Branch-count outliers (>3× same-order solved CP-SAT median, ≥5 CP-SAT peers, >50 branches): 0.
This is a triage rule, not a statistical significance test.

## Extreme-edge observations

Cumulative checkpoint contains 6 partially or fully probed trees.
`analysis.json` records every edge orbit, witnesses, exclusions reported by the solver,
and untested/unknown orbits. Each checked exclusion is explicitly marked with its proof status.
Infeasibility for a prescribed edge does not imply that the tree is nongraceful.

## Proposed next experiments (unproven)

- **pendant-extreme-support-lobsters**: For every lobster T that is not a caterpillar, there is a graceful labeling whose edge of difference |V(T)|-1 is incident to a leaf. Status: candidate question; truth and novelty not asserted. Enumerate non-caterpillar lobsters at a declared order; test every pendant edge orbit. Caterpillars already satisfy this by the known construction. One verified pendant witness establishes the property for that tree. Excluding all pendant orbits requires independently checked UNSAT evidence.

## Reproducibility and coverage

See `manifest.json` for exact versions, seeds, source hashes, configuration, hardware,
generation cursors and cumulative counts. `attempts.jsonl` and CSV describe this run;
`research.sqlite` carries the complete accumulated inputs, attempts, witnesses and proof text.
`unsat-certificates/` contains checked negative certificates; each binds the exact input and restriction.
`certificates/` contains standalone witnesses. Model/parameter/response protos are retained
per attempt when the worker reached those stages. `checksums.json` covers saved files.
Run `graceful-research audit RUN_DIRECTORY` before using results.

Cumulative unique inputs: 50; cumulative attempts: 59.
Generation stopping or exhausting a configured stream alone does not certify exhaustive
gracefulness verification. Inspect unresolved inputs and enumeration counts as well.


## Focused nightly investigation

Can a non-caterpillar lobster with matching deficiency at least two put its maximum difference on a leaf edge?

Study: **pendant**. Saved 3 records; stop: `batch_limit`.

[Machine-readable study summary](focused/summary.json). Detailed inputs and evidence are under `focused/records/`.

These observations do not extend exhaustive coverage or assert mathematical novelty.

```json
{
  "outcomes": {
    "supported": 3
  },
  "targets": 3,
  "trees_reviewed": 3
}
```