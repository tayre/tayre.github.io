# Graceful tree research run

Run `2026-11-15T015142.343933_0000-d00b6401` · campaign `focused-validation-v1`

Started 2026-11-15T01:51:42.344056+00:00; stopped for **case_limit**.
Elapsed 0.803s; configured budget 30s.

[Open the offline visual progress report](report.html) · [Chart data](progress.json) · [Notable review candidates](findings.json)

Download and extract the complete run artifact to open the HTML report and its evidence links.
The charts combine cumulative checkpoint history with this run's search effort.

![Cumulative research progress, size/family outcomes, and current-run search effort](figures/overview.png)

## Evidence summary

- Unique trees investigated (including probes): **54**.
- Unrestricted trees: **50**; verified graceful: **50**.
- Unrestricted unknown: **0**; solver-reported infeasible: **0**.
- Unrestricted trees with independently checked UNSAT certificates: **0**.
- Restricted attempts with independently checked UNSAT certificates: **1** (not counterexamples).
- Attempts: **58** (8 restricted probes).
- Unknown attempts: **0**; observed timeouts: **0**.
- Verified labeling certificates: **57**; errors: **0**.
- Restricted solver-infeasible attempts: **1**, kept separate from the main search.
- Attempts by method: caterpillar-construction: **24**; frontier-search: **26**; sat-drup: **8**. Unrecorded includes attempts interrupted before the worker returned a method.

A timeout is unresolved. A CP-SAT INFEASIBLE result is a solver conclusion, not an
independently checked proof certificate. No counterexample is declared automatically.
The SAT backend saves scoped DRUP proofs and checks them against an independently regenerated CNF.
These experiments do not prove the universal conjecture or establish novelty.

## Research budget use

Eligible unresolved/pending trees at start: 0.
Phase wall times include generation and dispatch; setup and final reporting are separate.
Unused retry time flows to new trees; enabled budget filling also reuses unspent probe time.

| Phase | Attempts | Wall seconds |
| --- | ---: | ---: |
| retries | 0 | 0.000 |
| new trees | 50 | 0.336 |
| edge probes | 8 | 0.060 |
| focused study | 0 | 0.226 |

## Tree sizes (unrestricted searches)

| Vertices | Trees |
| --- | ---: |
| 12 | 22 |
| 20 | 28 |

## Performance by input family and size

Family is the first generator that introduced a tree, not an exclusive mathematical classification.
Medians use solved CP-SAT cases only; construction and frontier witnesses have no CP-SAT time or branch count.
Unknowns are censored; different sizes, budgets, hardware
or successful subsets are not controlled comparisons.

| Family | n | Trees | Verified | Unknown | Infeasible | Solved median s | Median branches |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| caterpillar | 12 | 7 | 7 | 0 | 0 | — | None |
| caterpillar | 20 | 8 | 8 | 0 | 0 | — | None |
| lobster | 12 | 8 | 8 | 0 | 0 | — | None |
| lobster | 20 | 8 | 8 | 0 | 0 | — | None |
| prufer | 12 | 5 | 5 | 0 | 0 | — | None |
| prufer | 20 | 8 | 8 | 0 | 0 | — | None |
| spider | 12 | 2 | 2 | 0 | 0 | — | None |
| spider | 20 | 4 | 4 | 0 | 0 | — | None |

## Cases to investigate

Unresolved and infeasible cases come first, then deterministic work and branch count.
Wall times include dispatch overhead; exact inputs and all attempts are in the ledger.

| Tree ID | n | Family | Status | Wall s | Branches | Leaves | Diameter |
| --- | ---: | --- | --- | ---: | ---: | ---: | ---: |
| [26c847c9b59a](inputs/26c847c9b59a7ae7466fa7ebbd35cdd7b0d8b8465b5a8ee3b92cf189e3ab14ba.json) | 12 | prufer | verified_graceful | 0.077 | — | 7 | 6 |
| [7fb6be40c03e](inputs/7fb6be40c03ea097f4ed1a745ec00cb5e3f73ac4f170ea5c77bfc95ac16bce34.json) | 12 | caterpillar | verified_graceful | 0.009 | — | 5 | 8 |
| [95e4cb1ad0bc](inputs/95e4cb1ad0bc95ff3a1f31305af9608fc5de1128aa75c856998b14a688751752.json) | 20 | prufer | verified_graceful | 0.002 | — | 8 | 11 |
| [e2f16d796e41](inputs/e2f16d796e4120c26cdc4b906ac50390f144a76132db5bee3ce15228bfe7b26e.json) | 20 | spider | verified_graceful | 0.001 | — | 3 | 16 |
| [e08f27e4baaa](inputs/e08f27e4baaa57f34959a8ae8774567452ab6e25f49c42a0b11ef0ce8c08177d.json) | 20 | prufer | verified_graceful | 0.001 | — | 9 | 10 |
| [ead44ac39ac8](inputs/ead44ac39ac8a3a9ee02842944cb3d84da48e9915665e0a05d7eaf29d7a65977.json) | 20 | lobster | verified_graceful | 0.001 | — | 12 | 7 |
| [538e3c9e9d3d](inputs/538e3c9e9d3d4642fe4b6f67ccf0c93ee953078f11088f64557ca63c8424bf8f.json) | 20 | prufer | verified_graceful | 0.001 | — | 10 | 10 |
| [28798b78e8db](inputs/28798b78e8db856c6590cd0880bc3b201fd751b45d7b85591e8aeb5395008a4f.json) | 20 | lobster | verified_graceful | 0.001 | — | 13 | 7 |
| [3a995f02b4cb](inputs/3a995f02b4cbb8b8da437f751231955984a82528d2593f3ef24c299d5c780a2e.json) | 20 | spider | verified_graceful | 0.001 | — | 6 | 9 |
| [26cc5ac12765](inputs/26cc5ac12765965f556a44e3424e700c8ae40b04147756b74816a858f5aa0953.json) | 20 | spider | verified_graceful | 0.001 | — | 4 | 12 |
| [6bc5571ff8f5](inputs/6bc5571ff8f546c416f1740834826ec6b409ce0946473980ec31218be3f5866c.json) | 20 | lobster | verified_graceful | 0.001 | — | 11 | 9 |
| [483d6b30c119](inputs/483d6b30c1197344197dc9c125046045c796ec731630137c29232708366eac48.json) | 20 | lobster | verified_graceful | 0.001 | — | 12 | 7 |
| [f3384b80df51](inputs/f3384b80df512d450f71807c9f5f69902f027ccc3e1121943d377e826a2d5672.json) | 20 | lobster | verified_graceful | 0.001 | — | 11 | 8 |
| [e1cd0e54ba51](inputs/e1cd0e54ba515a12c79b8ab0791f08106b327e1a380c0201f72549256868075d.json) | 20 | prufer | verified_graceful | 0.001 | — | 9 | 8 |
| [43ae5fc3c74f](inputs/43ae5fc3c74f7712b125bba51c6ded6d99eeb3099fd2a4ed1f1fdbb37cf5c143.json) | 12 | lobster | verified_graceful | 0.001 | — | 7 | 5 |

Branch-count outliers (>3× same-order solved CP-SAT median, ≥5 CP-SAT peers, >50 branches): 0.
This is a triage rule, not a statistical significance test.

## Extreme-edge observations

Cumulative checkpoint contains 12 partially or fully probed trees.
`analysis.json` records every edge orbit, witnesses, exclusions reported by the solver,
and untested/unknown orbits. Each checked exclusion is explicitly marked with its proof status.
Infeasibility for a prescribed edge does not imply that the tree is nongraceful.

## Proposed next experiments (unproven)

- **pendant-extreme-support-lobsters**: For every lobster T that is not a caterpillar, there is a graceful labeling whose edge of difference |V(T)|-1 is incident to a leaf. Status: candidate question; truth and novelty not asserted. Enumerate non-caterpillar lobsters at a declared order; test every pendant edge orbit. Caterpillars already satisfy this by the known construction. One verified pendant witness establishes the property for that tree. Excluding all pendant orbits requires independently checked UNSAT evidence.

## Reproducibility and coverage

See `manifest.json` for exact versions, seeds, source hashes, configuration, hardware,
generation cursors and cumulative counts. `attempts.jsonl` and CSV describe this run;
`research.sqlite` carries the complete accumulated inputs, attempts, witnesses and proof text.
`unsat-certificates/` contains checked negative certificates; each binds the exact input and restriction.
`certificates/` contains standalone witnesses. Model/parameter/response protos are retained
per attempt when the worker reached those stages. `checksums.json` covers saved files.
Run `graceful-research audit RUN_DIRECTORY` before using results.

Cumulative unique inputs: 150; cumulative attempts: 175.
Generation stopping or exhausting a configured stream alone does not certify exhaustive
gracefulness verification. Inspect unresolved inputs and enumeration counts as well.


## Focused nightly investigation

Which small partial assignments observed in real search fail despite individually feasible branches?

Study: **residual**. Saved 3 records; stop: `batch_limit`.

[Machine-readable study summary](focused/summary.json). Detailed inputs and evidence are under `focused/records/`.

These observations do not extend exhaustive coverage or assert mathematical novelty.

```json
{
  "completable": 12,
  "congruence_certificates": 0,
  "impossible_partial": 0,
  "locally_feasible_but_incompatible": 0,
  "novelty_claimed": false,
  "relaxation_certificates": 0,
  "residuals": 12,
  "trace_inputs": 3,
  "unclassified_snapshots": 0,
  "whole_tree_infeasibility_claims": 0
}
```