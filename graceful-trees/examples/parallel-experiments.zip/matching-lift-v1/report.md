# Perfect-matching lift experiment

35 unique input trees; 28 independently verified labelings; 27 inputs have a perfect matching.

This implements the known Broersma–Hoede construction. Pair contraction reduces a 2s-vertex tree to an s-vertex contree. A graceful contree witness is lifted using even/odd labels, with opposite parity inside each matched pair and equal parity on external edges. Every lifted witness is independently verified.

| Termination | Cases |
| --- | ---: |
| no_perfect_matching | 7 |
| witness | 28 |

No perfect matching means only that this construction is unavailable. Failure to label a contree, exhaustion of the work allowance, or a timeout does not establish that the original tree is nongraceful. No negative tree certificates are produced.

The corpus intentionally favors matching-rich structures and includes negative applicability controls. It is not a natural random-tree sample. This functional run may be concurrent with other work; recorded elapsed times are not a speed comparison. A separate frozen, equal-time comparison is required before adoption.

## Reproduction

`inputs.json` records every original tree. Per-case files retain every contraction, vertex-to-core map, matching, core witness/search, parity choice, lifted labeling, and independent verification. Source snapshots, dependency versions and checksums are retained. This archive is not a campaign checkpoint.

`python scripts/experiment_matching_lift.py --output results/matching-lift`
