# Prescribed-zero symmetric spider experiment

The target is zero at the midpoint of a four-edge leg, on equal-leg spiders with 3–8 legs. The literature review identified this as a specific unresolved orbit in Rofa's symmetric-spider question; finite tests do not settle that question.

![Coverage of the five root-distance orbits on equal-leg length-four spiders with 3–8 legs. Green cells have independently verified graceful witnesses with the indicated vertex labeled zero; finite cases only.](figures/root-orbit-coverage.svg)

[PNG figure](figures/root-orbit-coverage.png) · [machine-readable coverage](figures/root-orbit-coverage.json). Each row is one tree shape and each column one root orbit. A verified cell asserts only that finite constrained instance.

| Legs | Vertices | Target outcome | Labels along each leg, from the hub outward |
| ---: | ---: | --- | --- |
| 3 | 13 | verified_graceful | hub 1; [12, 0, 10, 4]; [9, 5, 3, 6]; [8, 7, 2, 11] |
| 4 | 17 | verified_graceful | hub 2; [16, 0, 15, 3]; [11, 7, 10, 8]; [1, 14, 4, 9]; [13, 5, 12, 6] |
| 5 | 21 | verified_graceful | hub 19; [18, 0, 20, 1]; [5, 12, 14, 9]; [3, 16, 6, 10]; [2, 17, 11, 8]; [7, 15, 4, 13] |
| 6 | 25 | verified_graceful | hub 4; [23, 0, 24, 2]; [22, 1, 21, 5]; [17, 11, 12, 8]; [14, 9, 16, 13]; [15, 7, 19, 10]; [6, 20, 3, 18] |
| 7 | 29 | verified_graceful | hub 2; [28, 0, 27, 14]; [25, 3, 23, 6]; [17, 8, 16, 9]; [26, 1, 22, 10]; [20, 4, 5, 19]; [13, 15, 18, 24]; [21, 11, 7, 12] |
| 8 | 33 | verified_graceful | hub 2; [32, 0, 31, 3]; [26, 8, 23, 12]; [14, 17, 13, 18]; [21, 30, 1, 9]; [29, 4, 24, 10]; [28, 6, 27, 11]; [19, 20, 7, 5]; [25, 15, 22, 16] |

## Outcomes by scope

| Scope | Outcomes |
| --- | --- |
| midpoint_target | {"verified_graceful": 6} |
| known_orbit_control | {"verified_graceful": 24} |
| permutation_control | {"verified_graceful": 10, "solver_infeasible": 1} |

All positive solutions passed a full independent graceful-labeling verifier and a separate root-zero check. Tiny controls are also checked by complete permutation enumeration. A solver-infeasible answer excludes only the prescribed root and is not a checkable negative proof certificate. Unknowns and skipped cases remain unresolved.

## Reproducibility and limits

Six midpoint targets on equal-leg length-four spiders with 3..8 legs, followed by the other four root orbits for each shape and eleven tiny permutation controls. One representative per symmetric leg orbit; no root or complement constraint is imposed as symmetry breaking. The prescribed zero is the experiment itself. CP-SAT uses one worker and symmetry_level=0. Preparation counts against each attempt; the total solve loop is bounded, with output finalization afterward. Concurrent execution is permitted for functional evidence; timings are not performance comparisons.

Exact inputs, root restrictions, seeds, CP-SAT model and parameter files, witnesses, source snapshots, dependency versions and checksums are preserved. These are functional experiments, not isolated timing benchmarks, and no speed claim is made. The other root orbits are controls from the reviewed construction results; a timeout on a control does not contradict its theorem.

## Next mathematical step

Compare the verified midpoint witnesses by leg count for a parameterized formula. Any proposed formula must verify every label, every edge difference and the prescribed zero for arbitrary leg count; a finite witness table is insufficient. Do not infer obstruction from a solver cutoff. No new formula, general theorem or novelty is claimed in this run.

Source: [Rofa, symmetric rooted trees and spiders](https://arxiv.org/pdf/2312.16235).
