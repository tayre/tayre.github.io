# Congruence certificates for fixed residual forests

All 102 frozen cases were checked. Exactly 77 residuals are impossible and 25 complete. Independent global permutation checks agreed on every input (60,678 assignments examined).

| Observation | Cases |
| --- | ---: |
| Independently checked residual congruence certificate | 68 |
| Impossible, but no certificate for the tested primes | 9 |
| Feasible; no certificate | 25 |
| All branch tables nonempty, but jointly impossible | 30 |
| Such joint failures explained by a checked congruence | 21 |
| Certificates with every target resource appearing in some local option | 6 |

Each selected certificate has a modulus and weights for each individual branch, unused vertex label and required difference. Every valid local assignment has weighted sum zero modulo that modulus. The full target resources have nonzero weight. Any completion would sum local zero weights to that nonzero value, a contradiction.

Many exclusions are simple: a missing branch option or unused target resource already prevents completion. The full-coverage row isolates certificates for which that explanation alone is unavailable. All counts concern this frozen corpus, not arbitrary trees.

## A concrete parity certificate

Case 28 has unused labels {1,4,5} and remaining differences {1,2,3}. Branch instance 0 is the path 0–x–y; branch instance 1 is the leaf 2–z. Give weight 1 modulo 2 to branch instance 0, vertex label 4 and edge difference 2; give all other resources weight 0. Every valid local assignment has even total weight. The only valid assignment for the first branch is (x,y)=(1,4), of weight 2. For the leaf, labels 1,4,5 give differences 1,2,3 and weights 0,2,0, respectively. Any completion must use each branch and every label and difference once, for total weight 3, which is odd. This is a contradiction for this fixed residual only. Every resource appears in at least one local option.

Cases with no congruence certificate despite exact impossibility: 32, 50, 54, 55, 71, 72, 93, 95, 100. Each has an exhausted global-permutation oracle record; none is accepted as a congruence certificate. This explicitly demonstrates the relaxation's incompleteness.

## Trust boundary

The standalone standard-library checker validates the embedded input and regenerates all injective assignments for every branch. It does not trust saved signature tables or their claimed completeness, and does not use the discovery module, NetworkX, or a solver. The result certifies only the declared parent labels, branch shapes and remaining resources. It is not whole-tree infeasibility and does not enter the nightly campaign certificate counts. The checker implementation itself has tests and independent arithmetic structure, not a formal correctness proof.

## Limits and next questions

These are standard linear-functional certificates, not a novel theorem. Testing fields of orders 2,3,5,7 is not a complete integer-lattice membership test. Failure to find a certificate never establishes a completion. No conclusions about natural search-state frequency or speed follow from this deliberately structured, bounded corpus. Inspect the joint-failure certificates for repeated coefficient patterns; test any proposed general invariant on a fresh corpus and prove its stated scope before using it as a pruning rule.

## Reproduction

`python scripts/experiment_residual_congruence.py --output results/residual-congruence`

Inside the downloaded archive: `python3 -S residual_congruence_verify.py certificates`.

The archive preserves all exact inputs and original seeds, certificates, full per-case results, permutation-oracle records, dependency versions, source snapshots and checksums. It is a residual research archive, not a campaign checkpoint for graceful-research audit.
