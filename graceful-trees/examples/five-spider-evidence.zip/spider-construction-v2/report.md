# Closed-form symmetric-spider construction checks

All 338 complete witnesses passed independent verification: 68 known length-four controls and 270 length-five interior-root constructions.

![Three-leg, five-edge spider with vertex labels inside circles and edge differences beside lines. The depth-two vertex has label zero and the adjacent depth-three vertex has the maximum label fifteen.](figures/five-edge-witness.svg)

[PNG figure](figures/five-edge-witness.png) · [figure's full witness](figures/five-edge-witness.json) · [case table](cases.csv) · [machine-readable summary](summary.json).

## Scope and result

The corpus contains 68 distinct leg counts: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 100, 256, 1000, 10000. It checks 322,792 vertex occurrences and 322,454 edge occurrences across complete original trees. The largest tree has 50,001 vertices.

For each leg count, the length-four control places zero at a midpoint on the first leg. The length-five construction places zero at distance two or three, separately on the first and last legs; duplicate leg choices are omitted when there is only one leg. Every length-five certificate also passes the independent extreme-edge check between distances two and three.

## General proof and finite verification

The [general algebraic proof](source/docs/spider_formula_five.md) establishes the explicit length-five construction for every positive integer leg count. It partitions all vertex labels by residue modulo five and all edge weights into multiples of five and the absolute values of two arithmetic progressions. Complementation moves zero from distance two to distance three while preserving every edge difference.

This experiment checks the implementation on a finite corpus; its successful cases are not the proof of the universal statement. The four-edge midpoint construction is a specialization of known subdivision results. Research novelty of the five-edge formula remains unresolved by these checks. The [formal source](source/formal/Graceful/FiveSpider.lean) and its audit must be read for the exact scope of machine-checked claims.

## Reproducibility

All 338 full inputs, vertex labelings, prescribed roots and independent verifier outputs are retained in [certificates/](certificates/). The construction is deterministic and uses no seed or solver. The run snapshots 164 source files, records dependency versions and Git provenance, and hashes every retained artifact in [checksums.json](checksums.json).

These are mathematical correctness checks, not timing benchmarks. No speed claim, solver-default change, cloud scheduling change, or proof of the unrestricted graceful-tree conjecture is made.
