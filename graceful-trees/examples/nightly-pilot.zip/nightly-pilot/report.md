# Graceful tree research run

Run `2026-11-08T145941.586192_0000-bef65356` · campaign `nightly-v1`

Started 2026-11-08T14:59:41.586483+00:00; stopped for **compute_budget**.
Elapsed 36.618s; configured budget 45.0s.

## Evidence summary

- Unique trees investigated (including probes): **74**.
- Unrestricted trees: **74**; verified graceful: **70**.
- Unrestricted unknown: **4**; solver-reported infeasible: **0**.
- Independently certificate-verified infeasible: **0** (unsupported by this backend).
- Attempts: **114** (40 restricted probes).
- Unknown attempts: **4**; observed timeouts: **4**.
- Verified labeling certificates: **106**; errors: **0**.
- Restricted solver-infeasible attempts: **4**, kept separate from the main search.

A timeout is unresolved. A CP-SAT INFEASIBLE result is a solver conclusion, not an
independently checked proof certificate. No counterexample is declared automatically.
These experiments do not prove the universal conjecture or establish novelty.

## Tree sizes (unrestricted searches)

| Vertices | Trees |
| --- | ---: |
| 1 | 1 |
| 2 | 1 |
| 3 | 1 |
| 4 | 2 |
| 5 | 3 |
| 6 | 4 |
| 7 | 4 |
| 8 | 4 |
| 9 | 4 |
| 10 | 4 |
| 11 | 4 |
| 12 | 4 |
| 20 | 10 |
| 35 | 10 |
| 50 | 10 |
| 75 | 8 |

## Performance by input family and size

Family is the first generator that introduced a tree, not an exclusive mathematical classification.
Medians include solved cases only. Unknowns are censored; different sizes, budgets, hardware
or successful subsets are not controlled comparisons.

| Family | n | Trees | Verified | Unknown | Infeasible | Solved median s | Median branches |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| binary_heap | 20 | 1 | 1 | 0 | 0 | 0.0524 | 10226 |
| binary_heap | 35 | 1 | 1 | 0 | 0 | 0.1871 | 34916 |
| binary_heap | 50 | 1 | 1 | 0 | 0 | 0.8468 | 96740 |
| binary_heap | 75 | 1 | 1 | 0 | 0 | 4.6472 | 467126 |
| broom | 20 | 1 | 1 | 0 | 0 | 0.0349 | 9757 |
| broom | 35 | 1 | 1 | 0 | 0 | 0.1423 | 32954 |
| broom | 50 | 1 | 0 | 1 | 0 | — | None |
| broom | 75 | 1 | 0 | 1 | 0 | — | None |
| caterpillar | 20 | 1 | 1 | 0 | 0 | 0.0414 | 10127 |
| caterpillar | 35 | 1 | 1 | 0 | 0 | 0.1490 | 33365 |
| caterpillar | 50 | 1 | 1 | 0 | 0 | 0.4065 | 75259 |
| caterpillar | 75 | 1 | 0 | 1 | 0 | — | None |
| double_star | 20 | 1 | 1 | 0 | 0 | 0.0340 | 9456 |
| double_star | 35 | 1 | 1 | 0 | 0 | 0.1805 | 38311 |
| double_star | 50 | 1 | 1 | 0 | 0 | 0.3973 | 79233 |
| exhaustive | 1 | 1 | 1 | 0 | 0 | 0.0109 | 0 |
| exhaustive | 2 | 1 | 1 | 0 | 0 | 0.0010 | 0 |
| exhaustive | 3 | 1 | 1 | 0 | 0 | 0.0018 | 0 |
| exhaustive | 4 | 2 | 2 | 0 | 0 | 0.0009 | 32.0 |
| exhaustive | 5 | 3 | 3 | 0 | 0 | 0.0024 | 140 |
| exhaustive | 6 | 4 | 4 | 0 | 0 | 0.0032 | 431.0 |
| exhaustive | 7 | 4 | 4 | 0 | 0 | 0.0049 | 762.5 |
| exhaustive | 8 | 4 | 4 | 0 | 0 | 0.0063 | 1113.5 |
| exhaustive | 9 | 4 | 4 | 0 | 0 | 0.0094 | 1548.5 |
| exhaustive | 10 | 4 | 4 | 0 | 0 | 0.0096 | 2079.0 |
| exhaustive | 11 | 4 | 4 | 0 | 0 | 0.0115 | 2606.0 |
| exhaustive | 12 | 4 | 4 | 0 | 0 | 0.0141 | 3183.0 |
| lobster | 20 | 1 | 1 | 0 | 0 | 0.0365 | 9732 |
| lobster | 35 | 1 | 1 | 0 | 0 | 0.1391 | 32355 |
| lobster | 50 | 1 | 1 | 0 | 0 | 0.4736 | 76588 |
| lobster | 75 | 1 | 1 | 0 | 0 | 2.1289 | 218186 |
| path | 20 | 1 | 1 | 0 | 0 | 0.0384 | 9749 |
| path | 35 | 1 | 1 | 0 | 0 | 0.1904 | 34407 |
| path | 50 | 1 | 1 | 0 | 0 | 0.4036 | 69218 |
| path | 75 | 1 | 1 | 0 | 0 | 0.8887 | 153711 |
| prufer | 20 | 1 | 1 | 0 | 0 | 0.0469 | 10334 |
| prufer | 35 | 1 | 1 | 0 | 0 | 0.1382 | 32844 |
| prufer | 50 | 1 | 1 | 0 | 0 | 0.5031 | 77870 |
| prufer | 75 | 1 | 1 | 0 | 0 | 1.3080 | 173831 |
| recursive | 20 | 1 | 1 | 0 | 0 | 0.0517 | 9844 |
| recursive | 35 | 1 | 1 | 0 | 0 | 0.1350 | 32194 |
| recursive | 50 | 1 | 1 | 0 | 0 | 0.6708 | 83266 |
| recursive | 75 | 1 | 1 | 0 | 0 | 0.9734 | 165985 |
| spider | 20 | 1 | 1 | 0 | 0 | 0.0503 | 10232 |
| spider | 35 | 1 | 1 | 0 | 0 | 0.5866 | 107781 |
| spider | 50 | 1 | 1 | 0 | 0 | 0.3193 | 67202 |
| star | 20 | 1 | 1 | 0 | 0 | 0.0198 | 4687 |
| star | 35 | 1 | 1 | 0 | 0 | 3.0170 | 398537 |
| star | 50 | 1 | 1 | 0 | 0 | 0.1778 | 32748 |
| star | 75 | 1 | 0 | 1 | 0 | — | None |

## Cases to investigate

Unresolved and infeasible cases come first, then deterministic work and branch count.
Wall times include dispatch overhead; exact inputs and all attempts are in the ledger.

| Tree ID | n | Family | Status | Wall s | Branches | Leaves | Diameter |
| --- | ---: | --- | --- | ---: | ---: | ---: | ---: |
| [c3b4da66efa5](inputs/c3b4da66efa5fbe51368549d0c7df4029837b33222d60c496bf54c7497da4750.json) | 75 | star | unknown | 5.010 | 668063 | 74 | 2 |
| [ab8f0e32a2dd](inputs/ab8f0e32a2dd1eef0dbc305254d304e93617162659ed0e15d869e8bbfacd8683.json) | 50 | broom | unknown | 5.009 | 580061 | 38 | 13 |
| [5f2f12587dca](inputs/5f2f12587dcaaf5b09f5115ebc51fd532c7ce65b7788858db5c7622285090b52.json) | 75 | caterpillar | unknown | 5.013 | 554363 | 11 | 65 |
| [5f903b426fd7](inputs/5f903b426fd7275667a419a311e3e72484b7d5482e31ba09ff9267fb9627548b.json) | 75 | broom | unknown | 0.804 | 152941 | 60 | 16 |
| [9ba09351f057](inputs/9ba09351f057cf20bbda07d6605538764812f251a9a0d5dcc6c3e88c22459428.json) | 75 | binary_heap | verified_graceful | 4.654 | 467126 | 38 | 11 |
| [7ddf13cbf7ff](inputs/7ddf13cbf7ff527b321bcf104e4b6416463cbc444613aac92c39b3961b699dc3.json) | 35 | star | verified_graceful | 3.020 | 398537 | 34 | 2 |
| [c08ae0d4eccc](inputs/c08ae0d4ecccce89b00e6db48d800cd03297b52c6c6b41403fd5103720b49637.json) | 75 | lobster | verified_graceful | 2.136 | 218186 | 36 | 26 |
| [554c61ae8378](inputs/554c61ae8378afa39942b7c7c98e4d58572c264d5511033fef6ea3777b6ee1be.json) | 75 | prufer | verified_graceful | 1.315 | 173831 | 28 | 23 |
| [611a9308d140](inputs/611a9308d140468d2c975f5169e02f2ee529b48baf70cf1b02e71d6d0e78dec6.json) | 75 | recursive | verified_graceful | 0.980 | 165985 | 43 | 13 |
| [4101ffc24071](inputs/4101ffc2407153f30ad4b4056a5bfb0e9989062c86b4b526c94abe4806382d21.json) | 75 | path | verified_graceful | 0.895 | 153711 | 2 | 74 |
| [f601ac4c7118](inputs/f601ac4c71188ae24362616259953acf34d30dfac5c42884796f05d0b6b8f215.json) | 50 | binary_heap | verified_graceful | 0.851 | 96740 | 25 | 10 |
| [f6179dfbf43c](inputs/f6179dfbf43c907fd187a7f0854897480ccfcf3417cc4f5feadea38e0ec265f7.json) | 50 | recursive | verified_graceful | 0.675 | 83266 | 26 | 10 |
| [d9dafbf1cdfc](inputs/d9dafbf1cdfcd2515cf0f6331e8f6fba19f56d7b3a6c8c7b02599025cf3a93b8.json) | 35 | spider | verified_graceful | 0.590 | 107781 | 6 | 15 |
| [33a92666e38c](inputs/33a92666e38ce41ee277ed0b2ded7dce04689bce704a3db7c6d20d8bd2d0b58c.json) | 50 | prufer | verified_graceful | 0.508 | 77870 | 18 | 20 |
| [081d3f312f5f](inputs/081d3f312f5f5165541750d99b3473c7c8a54ca28dd60286e4a219e52cfb720c.json) | 50 | lobster | verified_graceful | 0.478 | 76588 | 27 | 18 |

Branch-count outliers (>3× same-order solved median, ≥5 peers, >50 branches): 5.
This is a triage rule, not a statistical significance test.

## Extreme-edge observations

Cumulative checkpoint contains 15 partially or fully probed trees.
`analysis.json` records every edge orbit, witnesses, exclusions reported by the solver,
and untested/unknown orbits. Only witnessed membership is independently verified.
Infeasibility for a prescribed edge does not imply that the tree is nongraceful.

## Proposed next experiments (unproven)

- **pendant-extreme-support**: For every caterpillar T with at least two vertices, there is a graceful labeling whose edge of difference |V(T)|-1 is incident to a leaf. Status: candidate question; truth and novelty not asserted. Enumerate caterpillars at a declared order; test every pendant edge orbit. One verified pendant witness establishes the property for that tree. Excluding all pendant orbits requires independently checked UNSAT evidence.
- **censored-retries**: Repeat unresolved inputs with larger budgets and multiple logged seeds. Status: algorithm benchmark, not a mathematical conjecture. Match size, solver version, model options and CPU; report censoring explicitly.
- **structural-search-cost**: At fixed order and fixed CP-SAT configuration, lower leaf fraction predicts a higher median branch count across a fixed list of seeds. Status: unvalidated performance hypothesis; no claim about gracefulness. Use size-matched cohorts with at least 20 trees and 5 seeds per tree. Include unknowns as censored observations; do not compare solved-only averages as if they represented the whole cohort.

## Reproducibility and coverage

See `manifest.json` for exact versions, seeds, source hashes, configuration, hardware,
generation cursors and cumulative counts. `attempts.jsonl` and CSV describe this run;
`research.sqlite` carries the complete accumulated inputs, attempts and positive witnesses.
`certificates/` contains standalone witnesses. Model/parameter/response protos are retained
per attempt when the worker reached those stages. `checksums.json` covers saved files.
Run `graceful-research audit RUN_DIRECTORY` before using results.

Cumulative unique inputs: 74; cumulative attempts: 114.
Generation stopping or exhausting a configured stream alone does not certify exhaustive
gracefulness verification. Inspect unresolved inputs and enumeration counts as well.
