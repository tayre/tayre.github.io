# Graceful tree research run

Run `2026-11-09T040236.004380_0000-12f3ee2f` · campaign `nightly-v1`

Started 2026-11-09T04:02:36.004706+00:00; stopped for **case_limit**.
Elapsed 0.716s; configured budget 40s.

[Open the offline visual progress report](report.html) · [Chart data](progress.json) · [Notable review candidates](findings.json)

Download and extract the complete run artifact to open the HTML report and its evidence links.
The charts combine cumulative checkpoint history with this run's search effort.

![Cumulative research progress, size/family outcomes, and current-run search effort](figures/overview.png)

## Evidence summary

- Unique trees investigated (including probes): **41**.
- Unrestricted trees: **40**; verified graceful: **40**.
- Unrestricted unknown: **0**; solver-reported infeasible: **0**.
- Unrestricted trees with independently checked UNSAT certificates: **0**.
- Restricted attempts with independently checked UNSAT certificates: **0** (not counterexamples).
- Attempts: **80** (40 restricted probes).
- Unknown attempts: **0**; observed timeouts: **0**.
- Verified labeling certificates: **80**; errors: **0**.
- Restricted solver-infeasible attempts: **0**, kept separate from the main search.
- Attempts by method: caterpillar-construction: **20**; frontier-search: **20**; sat-drup: **40**. Unrecorded includes attempts interrupted before the worker returned a method.

A timeout is unresolved. A CP-SAT INFEASIBLE result is a solver conclusion, not an
independently checked proof certificate. No counterexample is declared automatically.
The SAT backend saves scoped DRUP proofs and checks them against an independently regenerated CNF.
These experiments do not prove the universal conjecture or establish novelty.

## Tree sizes (unrestricted searches)

| Vertices | Trees |
| --- | ---: |
| 8 | 3 |
| 9 | 3 |
| 10 | 3 |
| 11 | 3 |
| 12 | 4 |
| 20 | 5 |
| 35 | 6 |
| 50 | 6 |
| 75 | 7 |

## Performance by input family and size

Family is the first generator that introduced a tree, not an exclusive mathematical classification.
Medians use solved CP-SAT cases only; construction and frontier witnesses have no CP-SAT time or branch count.
Unknowns are censored; different sizes, budgets, hardware
or successful subsets are not controlled comparisons.

| Family | n | Trees | Verified | Unknown | Infeasible | Solved median s | Median branches |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| broom | 35 | 1 | 1 | 0 | 0 | — | None |
| broom | 50 | 1 | 1 | 0 | 0 | — | None |
| broom | 75 | 1 | 1 | 0 | 0 | — | None |
| caterpillar | 20 | 1 | 1 | 0 | 0 | — | None |
| caterpillar | 35 | 1 | 1 | 0 | 0 | — | None |
| caterpillar | 50 | 1 | 1 | 0 | 0 | — | None |
| caterpillar | 75 | 1 | 1 | 0 | 0 | — | None |
| double_star | 75 | 1 | 1 | 0 | 0 | — | None |
| exhaustive | 8 | 3 | 3 | 0 | 0 | — | None |
| exhaustive | 9 | 3 | 3 | 0 | 0 | — | None |
| exhaustive | 10 | 3 | 3 | 0 | 0 | — | None |
| exhaustive | 11 | 3 | 3 | 0 | 0 | — | None |
| exhaustive | 12 | 4 | 4 | 0 | 0 | — | None |
| lobster | 20 | 1 | 1 | 0 | 0 | — | None |
| lobster | 35 | 1 | 1 | 0 | 0 | — | None |
| lobster | 50 | 1 | 1 | 0 | 0 | — | None |
| lobster | 75 | 1 | 1 | 0 | 0 | — | None |
| prufer | 20 | 1 | 1 | 0 | 0 | — | None |
| prufer | 35 | 1 | 1 | 0 | 0 | — | None |
| prufer | 50 | 1 | 1 | 0 | 0 | — | None |
| prufer | 75 | 1 | 1 | 0 | 0 | — | None |
| recursive | 20 | 1 | 1 | 0 | 0 | — | None |
| recursive | 35 | 1 | 1 | 0 | 0 | — | None |
| recursive | 50 | 1 | 1 | 0 | 0 | — | None |
| recursive | 75 | 1 | 1 | 0 | 0 | — | None |
| spider | 20 | 1 | 1 | 0 | 0 | — | None |
| spider | 35 | 1 | 1 | 0 | 0 | — | None |
| spider | 50 | 1 | 1 | 0 | 0 | — | None |
| spider | 75 | 1 | 1 | 0 | 0 | — | None |

## Cases to investigate

Unresolved and infeasible cases come first, then deterministic work and branch count.
Wall times include dispatch overhead; exact inputs and all attempts are in the ledger.

| Tree ID | n | Family | Status | Wall s | Branches | Leaves | Diameter |
| --- | ---: | --- | --- | ---: | ---: | ---: | ---: |
| [5b3f711b9849](inputs/5b3f711b984905a46bd2eb1767eec0ce179e5dc028de9026dd010fc6ba0ed048.json) | 12 | exhaustive | verified_graceful | 0.073 | — | 4 | 9 |
| [160f0bf410d1](inputs/160f0bf410d111ec5664496caecb3766851a7e38b8b573d39e073b0d082548ed.json) | 75 | recursive | verified_graceful | 0.052 | — | 37 | 13 |
| [01925b1c3cc6](inputs/01925b1c3cc679e73f4e3d032674cc3ecfc92ba388089e06b1a252b1c3c9a2e0.json) | 75 | lobster | verified_graceful | 0.015 | — | 41 | 27 |
| [b5fedf3b02c6](inputs/b5fedf3b02c68ae0a4a085b6e66ad3092e9930215a06f1f17d6657ec86bc608e.json) | 50 | lobster | verified_graceful | 0.010 | — | 28 | 17 |
| [84525217a959](inputs/84525217a959a46c70a1ae3d18121dc9af41308cef1fdeba96aa397a43a9ef5e.json) | 50 | recursive | verified_graceful | 0.010 | — | 24 | 15 |
| [3c0a8f839a46](inputs/3c0a8f839a46bfbd506556d9802ce33759ec2c188939c6d4de7d079e196c9f34.json) | 75 | prufer | verified_graceful | 0.006 | — | 31 | 22 |
| [043d36759f69](inputs/043d36759f6910bd92d62be5f6961b9cf15ad6eb8d4a73c05bd2dfb31a5e7b23.json) | 35 | prufer | verified_graceful | 0.002 | — | 12 | 14 |
| [f0b4f4e3e5b2](inputs/f0b4f4e3e5b24ee404f100f50c97c7f059e8444c81e8da805c22dddd2802bfc2.json) | 35 | lobster | verified_graceful | 0.002 | — | 21 | 14 |
| [5ddd64c4d090](inputs/5ddd64c4d090e36721a90e880ca1cb8bff1b3a5b0ba0b6986876ee63c5973c6e.json) | 75 | spider | verified_graceful | 0.002 | — | 7 | 29 |
| [1ebe3755ba68](inputs/1ebe3755ba68773adbc0fc95e38230f4d6d883a7b486a462d5f45279a6198e81.json) | 35 | recursive | verified_graceful | 0.001 | — | 19 | 9 |
| [477967f2e329](inputs/477967f2e3291080012f6efababc8e0fe362d51c208add888d9af7e7fc150650.json) | 20 | recursive | verified_graceful | 0.001 | — | 8 | 8 |
| [2ef37b864008](inputs/2ef37b864008711648d9657f63201ae1e7bb7104e9ac2f0dcf4b1867dd6f8c32.json) | 50 | prufer | verified_graceful | 0.001 | — | 22 | 17 |
| [31eeea2f8f2d](inputs/31eeea2f8f2dd7761b4b9284a0e020a23a6fdabb5e69540ec3465c283f7d2745.json) | 50 | spider | verified_graceful | 0.001 | — | 3 | 37 |
| [f92e18ffcbdc](inputs/f92e18ffcbdc41b64a573e2aabe1120883f26089ac6a3f23da9e5b3aecec27bc.json) | 35 | spider | verified_graceful | 0.001 | — | 3 | 26 |
| [4499346ba9b1](inputs/4499346ba9b1ef12768a14ce8f023d32aac6d148eeb0822e84470cc0284c9898.json) | 11 | exhaustive | verified_graceful | 0.001 | — | 4 | 7 |

Branch-count outliers (>3× same-order solved CP-SAT median, ≥5 CP-SAT peers, >50 branches): 0.
This is a triage rule, not a statistical significance test.

## Extreme-edge observations

Cumulative checkpoint contains 70 partially or fully probed trees.
`analysis.json` records every edge orbit, witnesses, exclusions reported by the solver,
and untested/unknown orbits. Each checked exclusion is explicitly marked with its proof status.
Infeasibility for a prescribed edge does not imply that the tree is nongraceful.

## Proposed next experiments (unproven)

- **pendant-extreme-support-lobsters**: For every lobster T that is not a caterpillar, there is a graceful labeling whose edge of difference |V(T)|-1 is incident to a leaf. Status: candidate question; truth and novelty not asserted. Enumerate non-caterpillar lobsters at a declared order; test every pendant edge orbit. Caterpillars already satisfy this by the known construction. One verified pendant witness establishes the property for that tree. Excluding all pendant orbits requires independently checked UNSAT evidence.

## Reproducibility and coverage

See `manifest.json` for exact versions, seeds, source hashes, configuration, hardware,
generation cursors and cumulative counts. `attempts.jsonl` and CSV describe this run;
`research.sqlite` carries the complete accumulated inputs, attempts, witnesses and proof text.
`unsat-certificates/` contains checked negative certificates; each binds the exact input and restriction.
`certificates/` contains standalone witnesses. Model/parameter/response protos are retained
per attempt when the worker reached those stages. `checksums.json` covers saved files.
Run `graceful-research audit RUN_DIRECTORY` before using results.

Cumulative unique inputs: 281; cumulative attempts: 609.
Generation stopping or exhausting a configured stream alone does not certify exhaustive
gracefulness verification. Inspect unresolved inputs and enumeration counts as well.
