# Frontier optimization experiment

Fixed before outcomes. Development/work use the earlier 48-tree portfolio corpus; holdout uses 64 new unique non-caterpillar shapes excluding all five earlier benchmark corpora: six per family at orders 35/75 and four at128 (Prüfer, recursive, spider, lobster). Work ablations allow 20,000 visits and30seconds, requiring no time cutoff; baseline and filter must return identical labels/nodes/roots/termination. Complete routes get the same attempt allowance and identical exact fallback; each candidate portfolio shares min(0.1s,10% of attempt) and40,000 nodes,20,000 perstage. Method order rotates by case/repetition. Imports warmed; no concurrent project CPU-heavy jobs. Every witness and fallback model hash is independently checked. No tuning after holdout. Adoption requires no lost cases in any paired repetition and lower median complete-route time; otherwise keep v3. Pipeline/ledger costs are measured separately.

![Verified counts and bounded workload times](comparison.svg)

| Method | Verified in every repetition | Median total seconds |
| --- | ---: | ---: |
| baseline | 43 / 48 | 0.268535 |
| filter | 43 / 48 | 0.224961 |
| memo | 46 / 48 | 0.595967 |
| orbits | 46 / 48 | 0.555745 |

All witnesses are independently checked. Unknowns are censored, never infeasible. The node budgets have identical numerical limits but orbit pruning changes the meaning of a visited node. Only the baseline/filter work ablation preserves the entire traversal. Timings cover this machine and workload, not expected nightly throughput or published state of the art. No novelty or theorem is claimed.

Per-repetition gained/lost cases, family/order totals and full evidence paths are in benchmark.json. These are benchmark artifacts, not campaign checkpoints.
