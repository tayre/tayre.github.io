# Graceful tree research run

Run `2026-11-09T040225.424254_0000-728766ca` · campaign `bitset-search-v1`

Started 2026-11-09T04:02:25.424474+00:00; stopped for **case_limit**.
Elapsed 0.665s; configured budget 60s.

[Open the offline visual progress report](report.html) · [Chart data](progress.json) · [Notable review candidates](findings.json)

Download and extract the complete run artifact to open the HTML report and its evidence links.
The charts combine cumulative checkpoint history with this run's search effort.

![Cumulative research progress, size/family outcomes, and current-run search effort](figures/overview.png)

## Evidence summary

- Unique trees investigated (including probes): **100**.
- Unrestricted trees: **100**; verified graceful: **100**.
- Unrestricted unknown: **0**; solver-reported infeasible: **0**.
- Unrestricted trees with independently checked UNSAT certificates: **0**.
- Restricted attempts with independently checked UNSAT certificates: **4** (not counterexamples).
- Attempts: **125** (25 restricted probes).
- Unknown attempts: **0**; observed timeouts: **0**.
- Verified labeling certificates: **121**; errors: **0**.
- Restricted solver-infeasible attempts: **4**, kept separate from the main search.
- Attempts by method: caterpillar-construction: **56**; frontier-search: **44**; sat-drup: **25**. Unrecorded includes attempts interrupted before the worker returned a method.

A timeout is unresolved. A CP-SAT INFEASIBLE result is a solver conclusion, not an
independently checked proof certificate. No counterexample is declared automatically.
The SAT backend saves scoped DRUP proofs and checks them against an independently regenerated CNF.
These experiments do not prove the universal conjecture or establish novelty.

## Tree sizes (unrestricted searches)

| Vertices | Trees |
| --- | ---: |
| 1 | 1 |
| 2 | 1 |
| 3 | 1 |
| 4 | 2 |
| 5 | 3 |
| 6 | 6 |
| 7 | 11 |
| 12 | 36 |
| 20 | 39 |

## Performance by input family and size

Family is the first generator that introduced a tree, not an exclusive mathematical classification.
Medians use solved CP-SAT cases only; construction and frontier witnesses have no CP-SAT time or branch count.
Unknowns are censored; different sizes, budgets, hardware
or successful subsets are not controlled comparisons.

| Family | n | Trees | Verified | Unknown | Infeasible | Solved median s | Median branches |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| binary_heap | 12 | 1 | 1 | 0 | 0 | — | None |
| binary_heap | 20 | 1 | 1 | 0 | 0 | — | None |
| caterpillar | 12 | 9 | 9 | 0 | 0 | — | None |
| caterpillar | 20 | 9 | 9 | 0 | 0 | — | None |
| exhaustive | 1 | 1 | 1 | 0 | 0 | — | None |
| exhaustive | 2 | 1 | 1 | 0 | 0 | — | None |
| exhaustive | 3 | 1 | 1 | 0 | 0 | — | None |
| exhaustive | 4 | 2 | 2 | 0 | 0 | — | None |
| exhaustive | 5 | 3 | 3 | 0 | 0 | — | None |
| exhaustive | 6 | 6 | 6 | 0 | 0 | — | None |
| exhaustive | 7 | 11 | 11 | 0 | 0 | — | None |
| lobster | 12 | 10 | 10 | 0 | 0 | — | None |
| lobster | 20 | 9 | 9 | 0 | 0 | — | None |
| path | 12 | 1 | 1 | 0 | 0 | — | None |
| path | 20 | 1 | 1 | 0 | 0 | — | None |
| prufer | 12 | 9 | 9 | 0 | 0 | — | None |
| prufer | 20 | 10 | 10 | 0 | 0 | — | None |
| spider | 12 | 5 | 5 | 0 | 0 | — | None |
| spider | 20 | 8 | 8 | 0 | 0 | — | None |
| star | 12 | 1 | 1 | 0 | 0 | — | None |
| star | 20 | 1 | 1 | 0 | 0 | — | None |

## Cases to investigate

Unresolved and infeasible cases come first, then deterministic work and branch count.
Wall times include dispatch overhead; exact inputs and all attempts are in the ledger.

| Tree ID | n | Family | Status | Wall s | Branches | Leaves | Diameter |
| --- | ---: | --- | --- | ---: | ---: | ---: | ---: |
| [287628c154e6](inputs/287628c154e67057da3fc8c08b47aa1cce86f2630bf810f9807e46c3ff0ab0bc.json) | 1 | exhaustive | verified_graceful | 0.072 | — | 0 | 0 |
| [a1e78ef910d4](inputs/a1e78ef910d49a801784544b54c67e983175d864773d8e0bdec4362235113df0.json) | 20 | binary_heap | verified_graceful | 0.004 | — | 10 | 7 |
| [6715c6dd4ac2](inputs/6715c6dd4ac27e67afb569c88baac89973f84eee5aee21f99d23c5c1c4809a93.json) | 20 | lobster | verified_graceful | 0.002 | — | 12 | 8 |
| [19ce0692caa3](inputs/19ce0692caa37072a957de57e631c258e89ccf5cae35fffdea562c180ecf4f1c.json) | 12 | binary_heap | verified_graceful | 0.001 | — | 6 | 6 |
| [1f815cdf55f7](inputs/1f815cdf55f7e3145ee5f961645443ef5672e6c6a9f5e09eb77b8eb82fbea02b.json) | 20 | lobster | verified_graceful | 0.001 | — | 11 | 8 |
| [10cde823d8aa](inputs/10cde823d8aad34542891f9ee94692eafb7b6632c2945e8336c5b575fd0472de.json) | 20 | lobster | verified_graceful | 0.001 | — | 11 | 7 |
| [9576fa150694](inputs/9576fa150694282404791b1b77148fd5836d211544f3c16f1671146154c875ae.json) | 20 | spider | verified_graceful | 0.001 | — | 4 | 11 |
| [98a4b7e9ac00](inputs/98a4b7e9ac003048e8681ff39ebd93ed77b0273fb18b75db35da75484f915081.json) | 12 | lobster | verified_graceful | 0.001 | — | 7 | 5 |
| [36f06aafd731](inputs/36f06aafd731525d3d51ee010db65b2576fe156c08e651d7bad6f6fc49fd2a67.json) | 20 | spider | verified_graceful | 0.001 | — | 4 | 14 |
| [3da2b7200915](inputs/3da2b720091558c8f09e7e82275c06d0d3e86d4155329986953a065cab6b614c.json) | 12 | spider | verified_graceful | 0.001 | — | 4 | 7 |
| [cef3ff810a56](inputs/cef3ff810a56f3232cecb3d62f45eb127ec61229c1aecf98e9de39aeeac448e9.json) | 20 | prufer | verified_graceful | 0.001 | — | 7 | 9 |
| [767e33a4711e](inputs/767e33a4711edf74552ff5f343fab9b675fa91f6fb0afbb21f2e2fe1792d6ab9.json) | 20 | spider | verified_graceful | 0.001 | — | 6 | 9 |
| [bb3e6016f499](inputs/bb3e6016f499a82bb8cbb20e66781d2916a4bce7cff33ee6a6c5e21e28b86247.json) | 20 | spider | verified_graceful | 0.001 | — | 4 | 12 |
| [020c71e9d95e](inputs/020c71e9d95e137bb21ede8b1dcf52b50c1e92ca6beadce39c9844e03f5e73d8.json) | 12 | prufer | verified_graceful | 0.001 | — | 6 | 6 |
| [f1c84c746cec](inputs/f1c84c746cec8bc0bd4a1ffc08c79be5db6f3226a62cce3bd71167cbb6e269e1.json) | 20 | prufer | verified_graceful | 0.001 | — | 10 | 9 |

Branch-count outliers (>3× same-order solved CP-SAT median, ≥5 CP-SAT peers, >50 branches): 0.
This is a triage rule, not a statistical significance test.

## Extreme-edge observations

Cumulative checkpoint contains 13 partially or fully probed trees.
`analysis.json` records every edge orbit, witnesses, exclusions reported by the solver,
and untested/unknown orbits. Each checked exclusion is explicitly marked with its proof status.
Infeasibility for a prescribed edge does not imply that the tree is nongraceful.

## Proposed next experiments (unproven)

- **pendant-extreme-support-lobsters**: For every lobster T that is not a caterpillar, there is a graceful labeling whose edge of difference |V(T)|-1 is incident to a leaf. Status: candidate question; truth and novelty not asserted. Enumerate non-caterpillar lobsters at a declared order; test every pendant edge orbit. Caterpillars already satisfy this by the known construction. One verified pendant witness establishes the property for that tree. Excluding all pendant orbits requires independently checked UNSAT evidence.

## Reproducibility and coverage

See `manifest.json` for exact versions, seeds, source hashes, configuration, hardware,
generation cursors and cumulative counts. `attempts.jsonl` and CSV describe this run;
`research.sqlite` carries the complete accumulated inputs, attempts, witnesses and proof text.
`unsat-certificates/` contains checked negative certificates; each binds the exact input and restriction.
`certificates/` contains standalone witnesses. Model/parameter/response protos are retained
per attempt when the worker reached those stages. `checksums.json` covers saved files.
Run `graceful-research audit RUN_DIRECTORY` before using results.

Cumulative unique inputs: 100; cumulative attempts: 125.
Generation stopping or exhausting a configured stream alone does not certify exhaustive
gracefulness verification. Inspect unresolved inputs and enumeration counts as well.
